(() => {
  "use strict";

  // =========================
  // ✅ [최우선] prototype 레벨 play() / volume / muted 차단
  // document_start에서 YouTube JS보다 먼저 실행되어
  // .play() 호출 자체를 가로채 mute 후 실행 → 소리 원천 차단
  // =========================
  (function patchMediaPrototype() {
    const _play = HTMLMediaElement.prototype.play;
    const _volumeDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "volume");
    const _mutedDesc  = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "muted");

    // 패치가 활성 상태인지 확인하는 플래그 (unpatch 후 false)
    let _patchActive = true;

    // volume setter: watch 페이지에서 항상 0 강제 (패치 활성 시)
    Object.defineProperty(HTMLMediaElement.prototype, "volume", {
      get: _volumeDesc.get,
      set: function(v) {
        if (_patchActive && location.pathname === "/watch") { _volumeDesc.set.call(this, 0); return; }
        _volumeDesc.set.call(this, v);
      },
      configurable: true,
    });

    // muted setter: watch 페이지에서 unmute 시도 차단 (패치 활성 시)
    Object.defineProperty(HTMLMediaElement.prototype, "muted", {
      get: _mutedDesc.get,
      set: function(v) {
        if (_patchActive && location.pathname === "/watch") { _mutedDesc.set.call(this, true); return; }
        _mutedDesc.set.call(this, v);
      },
      configurable: true,
    });

    // play(): watch 페이지에서 강제 mute 후 실행 (패치 활성 시)
    HTMLMediaElement.prototype.play = function() {
      if (_patchActive && location.pathname === "/watch") {
        try { _mutedDesc.set.call(this, true); } catch {}
        try { _volumeDesc.set.call(this, 0); } catch {}
        try { this.setAttribute("muted", ""); } catch {}
      }
      return _play.apply(this, arguments);
    };

    // 진짜 원본 descriptor를 외부에서 접근 가능하도록 노출 (패치 이후 getOwnPropertyDescriptor 하면 이미 교체된 값)
    window.__gysNativeVolDesc   = _volumeDesc;
    window.__gysNativeMutedDesc = _mutedDesc;
    window.__gysNativePlay      = _play;

    // 원본 플레이어 복귀 시 prototype 패치 비활성화
    window.__gysPatchUnmute = function() {
      _patchActive = false;
    };
    // 재차단이 필요할 때 (새 영상으로 이동 후 외부 플레이어 다시 사용)
    window.__gysPatchRemute = function() {
      _patchActive = true;
    };
  })();

  // =========================
  // 설정
  // =========================
  const CONFIG_URL = "https://youtube-extention.vercel.app/config";

  // ✅ HMAC 서명용 비밀키 (토큰을 직접 전송하지 않음)
  // 이 값은 서버의 GYS_HMAC_SECRET 환경변수와 동일해야 함
  const HMAC_SECRET = "267cd059b75c05f260d07209f1f43eaf26bad3ae4173cd7a85284423879f25b3";

  // 서버에서 받아올 값들
  let EXTERNAL_PLAYER_BASE = "";
  let AD_SELECTORS = [];
  let PLAYER_PARAMS = { start: "0", end: "0", rel: "0" };
  let EXTERNAL_ORIGIN = "";

  const CUSTOM_WRAPPER_ID = "gys-custom-player-wrapper";
  const CUSTOM_IFRAME_ID = "gys-custom-player-iframe";
  const STYLE_ID = "gys-custom-player-style";
  const READY_CLASS = "gys-custom-player-ready";

  const ALWAYS_MUTE_ORIGINAL = true;
  const ORIGINAL_PLAY_MS = 1000;
  const IFRAME_PREPLAY_MS = 5000; // iframe 먼저 재생할 시간 (이후 원본 1초 무음 재생)
  const FALLBACK_ALLOW_SOUND = true;
  const KILL_MINIPLAYER = true;

  // =========================
  // 상태
  // =========================
  let applying = false;
  let lastUrl = "";
  let _briefPlayActive = false; // 원본 1초 재생 구간 플래그 (이 구간엔 pause 차단)
  let lastExternalSrc = "";
  let pageType = "";
  let FORCE_ORIGINAL = false;
  let FORCE_VIDEO_ID = "";
  let configLoaded = false;

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  // =========================
  // ✅ HMAC-SHA256 서명 생성
  // =========================
  async function generateHmacSignature(message, secret) {
    const enc = new TextEncoder();
    const keyData = enc.encode(secret);
    const msgData = enc.encode(message);

    const cryptoKey = await crypto.subtle.importKey(
      "raw", keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );

    const signature = await crypto.subtle.sign("HMAC", cryptoKey, msgData);

    // ArrayBuffer → hex 문자열
    return Array.from(new Uint8Array(signature))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  // =========================
  // ✅ 서버에서 설정 받아오기 (HMAC 서명 포함)
  // =========================
  async function fetchConfig() {
    try {
      // 타임스탬프 + 랜덤값으로 매 요청마다 다른 서명 생성
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const nonce = crypto.randomUUID();
      const message = `${timestamp}:${nonce}`;

      const signature = await generateHmacSignature(message, HMAC_SECRET);

      const res = await fetch(CONFIG_URL, {
        headers: {
          "X-GYS-Timestamp": timestamp,
          "X-GYS-Nonce": nonce,
          "X-GYS-Signature": signature,
        },
      });

      if (!res.ok) throw new Error(`Config fetch failed: ${res.status}`);

      const data = await res.json();

      EXTERNAL_PLAYER_BASE = data.playerBase || "";
      AD_SELECTORS = data.adSelectors || [];
      PLAYER_PARAMS = data.playerParams || { start: "0", end: "0", rel: "0" };
      EXTERNAL_ORIGIN = data.playerBase ? new URL(data.playerBase).origin : "";

      configLoaded = true;
    } catch (e) {
      configLoaded = false;
      console.warn("[GYS] Config load failed. Extension disabled.");
    }
  }

  // =========================
  // 페이지 타입
  // =========================
  function isShortsPage() {
    return location.pathname.startsWith("/shorts");
  }
  function isWatchPage() {
    return location.pathname === "/watch";
  }
  function isHomeGridLikePage() {
    const p = location.pathname;
    return p === "/" || p.startsWith("/feed") || p.startsWith("/results");
  }
  function updatePageType() {
    if (isShortsPage()) pageType = "shorts";
    else if (isWatchPage()) pageType = "watch";
    else if (isHomeGridLikePage()) pageType = "grid";
    else pageType = "other";
  }

  // =========================
  // video id
  // =========================
  function getVideoIdFromUrl() {
    try {
      const u = new URL(location.href);
      return u.searchParams.get("v") || "";
    } catch {
      return "";
    }
  }

  // =========================
  // 외부 플레이어 URL
  // =========================
  function buildExternalSrc(videoId) {
    const u = new URL(EXTERNAL_PLAYER_BASE);
    u.searchParams.set("v", videoId);
    u.searchParams.set("start", String(PLAYER_PARAMS.start ?? "0"));
    u.searchParams.set("end", String(PLAYER_PARAMS.end ?? "0"));
    u.searchParams.set("rel", String(PLAYER_PARAMS.rel ?? "0"));
    return u.toString();
  }

  function getExternalOrigin() {
    return EXTERNAL_ORIGIN;
  }

  // =========================
  // ✅ 미니플레이어 완전 제거
  // =========================
  function killMiniPlayer() {
    if (!KILL_MINIPLAYER) return;
    try {
      document.querySelectorAll("ytd-miniplayer").forEach((el) => el.remove());
      document.querySelectorAll(".ytp-miniplayer-ui").forEach((el) => el.remove());
      const closeBtn = document.querySelector(".ytp-miniplayer-close-button");
      if (closeBtn) closeBtn.click();
      const flexy = document.querySelector("ytd-watch-flexy");
      if (flexy) {
        flexy.removeAttribute("miniplayer");
        flexy.classList.remove("miniplayer");
      }
    } catch {}
  }

  // =========================
  // 광고/빈칸 제거
  // =========================
  function removeYouTubeAds(root = document) {
    if (!configLoaded || AD_SELECTORS.length === 0) return;
    try {
      const sel = AD_SELECTORS.join(",");
      const isGrid = isHomeGridLikePage();
      root.querySelectorAll(sel).forEach((adEl) => {
        if (isGrid) {
          const container = adEl.closest("ytd-rich-item-renderer, ytd-rich-section-renderer");
          (container || adEl).remove();
        } else {
          adEl.remove();
        }
      });
    } catch {}
  }

  function cleanupGridHoles() {
    try {
      document
        .querySelectorAll(
          "ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-in-feed-ad-layout-renderer"
        )
        .forEach((el) => {
          const isEmpty =
            !el.innerText ||
            el.innerText.trim() === "" ||
            el.querySelector("ytd-display-ad-renderer, ytd-ad-slot-renderer");
          if (isEmpty) el.remove();
        });
    } catch {}
  }

  function forceGridReflow() {
    try {
      const grid = document.querySelector("ytd-rich-grid-renderer");
      if (!grid) return;
      grid.style.transform = "translateZ(0)";
      grid.offsetHeight;
      grid.style.transform = "";
    } catch {}
  }

  // =========================
  // UI 삽입
  // =========================
  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;
    const st = document.createElement("style");
    st.id = STYLE_ID;
    st.textContent = `
      #${CUSTOM_WRAPPER_ID}{
        position:absolute;
        inset:0;
        z-index:999999;
        display:none;
        background:#000;
      }
      #${CUSTOM_WRAPPER_ID} iframe{
        width:100%;
        height:100%;
        border:0;
        display:block;
      }
      body.${READY_CLASS} #${CUSTOM_WRAPPER_ID}{
        display:block;
      }
      ytd-miniplayer,
      .ytp-miniplayer-ui {
        display:none !important;
        visibility:hidden !important;
        pointer-events:none !important;
        opacity:0 !important;
      }
    `;
    document.documentElement.appendChild(st);
  }

  function ensureOverlayInsideMoviePlayer() {
    const movie = document.getElementById("movie_player");
    if (!movie) return false;
    movie.style.position = "relative";

    let wrap = document.getElementById(CUSTOM_WRAPPER_ID);
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.id = CUSTOM_WRAPPER_ID;
      const iframe = document.createElement("iframe");
      iframe.id = CUSTOM_IFRAME_ID;
      iframe.allow = "autoplay; encrypted-media; fullscreen; picture-in-picture";
      iframe.allowFullscreen = true;
      wrap.appendChild(iframe);
      movie.appendChild(wrap);
    }
    return true;
  }

  function setIframeSrcIfChanged(src) {
    if (!src || src === lastExternalSrc) return;
    lastExternalSrc = src;
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (!iframe) return;
    iframe.src = src;
  }

  function disableExternalPlayerOnNonWatch() {
    document.body.classList.remove(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "none";
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (iframe) {
      try { iframe.src = "about:blank"; } catch {}
    }
    lastExternalSrc = "";
  }

  function enableExternalPlayerUI() {
    // 외부 플레이어 활성화 시 prototype 패치 재활성화
    try { if (window.__gysPatchRemute) window.__gysPatchRemute(); } catch {}
    document.body.classList.add(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "block";
  }

  // =========================
  // 강제 무음
  // =========================
  let guardedMedia = new WeakSet();

  function hardMuteMedia(el) {
    if (!el) return;
    try {
      el.muted = true;
      el.defaultMuted = true;
      el.volume = 0;
      el.setAttribute("muted", "");
    } catch {}
  }

  function shouldMuteOriginalNow() {
    if (!ALWAYS_MUTE_ORIGINAL) return false;
    if (isShortsPage()) return false;
    if (FALLBACK_ALLOW_SOUND && FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) {
      return false;
    }
    return true;
  }

  function guardMediaElement(el) {
    if (!el || guardedMedia.has(el)) return;
    guardedMedia.add(el);
    if (shouldMuteOriginalNow()) hardMuteMedia(el);
    el.addEventListener("volumechange", () => {
      if (!shouldMuteOriginalNow()) return;
      hardMuteMedia(el);
    }, true);
    // play 이벤트에서도 즉시 무음 처리 (YouTube 볼륨 복원 차단)
    // FORCE_ORIGINAL 상태(폴백)면 개입하지 않음
    el.addEventListener("play", () => {
      if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return;
      if (_briefPlayActive) { hardMuteMedia(el); return; }
      if (!shouldMuteOriginalNow()) return;
      hardMuteMedia(el);
      try {
        const mp = document.getElementById("movie_player");
        if (mp?.mute) mp.mute();
        if (mp?.setVolume) mp.setVolume(0);
      } catch {}
    }, true);
  }

  function hardMuteAllMediaOnPage() {
    if (!shouldMuteOriginalNow()) return;
    document.querySelectorAll("video, audio").forEach((m) => {
      guardMediaElement(m);
      hardMuteMedia(m);
    });
    try {
      const mp = document.getElementById("movie_player");
      if (mp?.mute) mp.mute();
      if (mp?.setVolume) mp.setVolume(0);
    } catch {}
  }

  // =========================
  // watch 페이지 원본 정지
  // =========================
  const pauseTimerMap = new WeakMap();

  function playBrieflyMutedThenPause(videoEl) {
    if (!videoEl) return;
    if (pauseTimerMap.has(videoEl)) return;
    hardMuteMedia(videoEl);
    // movie_player API 레벨도 즉시 무음 (YouTube 내부 복원 방지)
    try {
      const mp = document.getElementById("movie_player");
      if (mp?.mute) mp.mute();
      if (mp?.setVolume) mp.setVolume(0);
    } catch {}
    const tid = setTimeout(() => {
      try { videoEl.pause(); } catch {}
      pauseTimerMap.delete(videoEl);
    }, ORIGINAL_PLAY_MS);
    pauseTimerMap.set(videoEl, tid);
  }

  function cancelPauseTimer(videoEl) {
    const tid = pauseTimerMap.get(videoEl);
    if (tid) {
      clearTimeout(tid);
      pauseTimerMap.delete(videoEl);
    }
  }

  // =========================
  // 미니플레이어 버튼/단축키 방지
  // =========================
  document.addEventListener("click", (e) => {
    const t = e.target;
    if (
      t?.closest(".ytp-miniplayer-button") ||
      t?.closest("[aria-label='미니플레이어']") ||
      t?.closest("[title*='미니플레이어']")
    ) {
      e.preventDefault();
      e.stopPropagation();
      killMiniPlayer();
    }
  }, true);

  document.addEventListener("keydown", (e) => {
    try {
      if (!KILL_MINIPLAYER) return;
      if (e.key?.toLowerCase() === "i") {
        const tag = (document.activeElement && document.activeElement.tagName) || "";
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        e.preventDefault();
        e.stopPropagation();
        killMiniPlayer();
      }
    } catch {}
  }, true);

  // =========================
  // watch 페이지 원본 영상 제어
  // =========================
  function stopOriginalYouTubeVideoOnWatchOnly() {
    if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) {
      if (!FALLBACK_ALLOW_SOUND) hardMuteAllMediaOnPage();
      return;
    }
    if (isShortsPage()) return;
    if (!isWatchPage()) return;
    document.querySelectorAll("video").forEach((v) => {
      try {
        guardMediaElement(v);
        hardMuteMedia(v);
        if (!v.paused) playBrieflyMutedThenPause(v);
      } catch {}
    });
  }

  function blockOriginalAutoplayByEvent() {
    document.addEventListener("play", (e) => {
      if (isShortsPage()) return;
      // FORCE_ORIGINAL 상태면 원본 플레이어 재생 허용 (mute/pause 차단 안 함)
      if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return;
      // 1초 원본 재생 구간에서는 pause 금지 (무음만 유지)
      if (_briefPlayActive) { if (shouldMuteOriginalNow()) hardMuteMedia(e.target); return; }
      const t = e.target;
      if (t && (t.tagName === "VIDEO" || t.tagName === "AUDIO")) {
        try {
          guardMediaElement(t);
          if (isWatchPage()) {
            if (shouldMuteOriginalNow()) hardMuteMedia(t);
            playBrieflyMutedThenPause(t);
          } else {
            if (shouldMuteOriginalNow()) hardMuteMedia(t);
          }
        } catch {}
      }
    }, true);
  }

  // =========================
  // 폴백: 원본 복귀
  // =========================
  // 진짜 원본 descriptor (patchMediaPrototype이 window에 노출한 값 사용)
  const _nativeVolDesc   = window.__gysNativeVolDesc;
  const _nativeMutedDesc = window.__gysNativeMutedDesc;
  const _nativePlay      = window.__gysNativePlay;

  function resumeOriginalPlayerPlayback() {
    try {
      const v = document.querySelector("#movie_player video.html5-main-video");
      if (!v) return;
      cancelPauseTimer(v);
      if (!FALLBACK_ALLOW_SOUND) {
        hardMuteMedia(v);
      } else {
        try {
          // prototype 패치 우회: 원본 descriptor로 직접 설정
          _nativeMutedDesc.set.call(v, false);
          v.defaultMuted = false;
          v.removeAttribute("muted");
          _nativeVolDesc.set.call(v, 1);
        } catch {}
        try {
          const mp = document.getElementById("movie_player");
          if (mp?.unMute) mp.unMute();
          if (mp?.setVolume) mp.setVolume(100);
        } catch {}
      }
      // 원본 play 직접 호출 (prototype 패치 우회)
      const p = _nativePlay.call(v);
      if (p && typeof p.catch === "function") p.catch(() => {});
      cancelPauseTimer(v);
    } catch {}
  }

  function fallbackToOriginalPlayer(videoId) {
    FORCE_ORIGINAL = true;
    FORCE_VIDEO_ID = videoId || "";

    // prototype 패치 비활성화
    try { if (window.__gysPatchUnmute) window.__gysPatchUnmute(); } catch {}

    // guardedMedia 초기화: 기존 video element에 붙은 mute 리스너 무력화
    guardedMedia = new WeakSet();

    disableExternalPlayerOnNonWatch();

    // 딜레이 후 재생 시도 (YouTube 내부 초기화 대기)
    const tryResume = (attempt) => {
      resumeOriginalPlayerPlayback();
      if (attempt < 5) {
        setTimeout(() => {
          if (!FORCE_ORIGINAL) return;
          const v = document.querySelector("#movie_player video.html5-main-video");
          if (v && v.paused) tryResume(attempt + 1);
        }, 300 * attempt || 100);
      }
    };
    tryResume(0);
    killMiniPlayer();
  }

  function hookEmbedErrorMessage() {
    const externalOrigin = getExternalOrigin();
    window.addEventListener("message", (ev) => {
      const d = ev?.data;
      if (!d || d.type !== "GYS_EMBED_ERROR") return;
      if (externalOrigin && ev.origin !== externalOrigin) return;
      const cur = getVideoIdFromUrl();
      if (!cur || cur !== d.videoId) return;
      fallbackToOriginalPlayer(d.videoId);
    });
  }

  function hookEmbedVideoEnded() {
    const externalOrigin = getExternalOrigin();
    window.addEventListener("message", (ev) => {
      try {
        const d = ev?.data;
        if (!d || d.type !== "GYS_VIDEO_ENDED") return;
        if (externalOrigin && ev.origin !== externalOrigin) return;
        if (!isWatchPage()) return;
        const nextBtn =
          document.querySelector(".ytp-next-button") ||
          document.querySelector("a.ytp-next-button") ||
          document.querySelector("[data-tooltip-target-id='ytp-autonav-toggle-button']");
        const currentItem = document.querySelector(
          "ytd-playlist-panel-video-renderer[selected], ytd-playlist-panel-video-renderer.iron-selected"
        );
        const nextItem = currentItem?.nextElementSibling?.closest("ytd-playlist-panel-video-renderer");
        const nextAnchor = nextItem?.querySelector("a#wc-endpoint, a.ytd-playlist-panel-video-renderer");
        if (nextAnchor?.href) {
          nextAnchor.click();
        } else if (nextBtn) {
          nextBtn.click();
        }
      } catch {}
    });
  }

  // =========================
  // URL 변경 감지 (SPA)
  // =========================
  function hookYouTubeNavigateEvents() {
    window.addEventListener("yt-navigate-finish", () => {
      killMiniPlayer(); updatePageType(); removeYouTubeAds();
      cleanupGridHoles(); forceGridReflow(); applyReplacePlayer(false);
    });
    window.addEventListener("popstate", () => {
      killMiniPlayer(); updatePageType(); removeYouTubeAds();
      cleanupGridHoles(); forceGridReflow(); applyReplacePlayer(false);
    });
  }

  function watchDomMutations() {
    const obs = new MutationObserver(() => {
      killMiniPlayer();
      try { removeYouTubeAds(); cleanupGridHoles(); forceGridReflow(); } catch {}
      // 폴백 상태에서는 applyReplacePlayer 호출 금지 (원본 재생 방해 방지)
      if (FORCE_ORIGINAL) return;
      applyReplacePlayer(false);
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
  }

  function startUrlPolling() {
    setInterval(() => {
      const urlNow = location.href;
      if (urlNow !== lastUrl) {
        killMiniPlayer(); updatePageType(); removeYouTubeAds();
        cleanupGridHoles(); forceGridReflow();
        // URL이 바뀌면 FORCE_ORIGINAL 해제 (다른 영상으로 이동)
        if (FORCE_ORIGINAL && getVideoIdFromUrl() !== FORCE_VIDEO_ID) {
          FORCE_ORIGINAL = false; FORCE_VIDEO_ID = "";
        }
        applyReplacePlayer(false);
      }
    }, 700);
  }

  // =========================
  // watch일 때만 외부 iframe으로 대체
  // =========================
  async function applyReplacePlayer(force) {
    if (!configLoaded) return;
    if (applying) return;
    applying = true;
    try {
      const urlNow = location.href;
      if (!force && urlNow === lastUrl) return;
      killMiniPlayer(); removeYouTubeAds(); cleanupGridHoles(); forceGridReflow();
      // FORCE_ORIGINAL 상태에서는 mute 금지
      if (!FORCE_ORIGINAL) hardMuteAllMediaOnPage();
      if (isShortsPage()) { disableExternalPlayerOnNonWatch(); lastUrl = urlNow; return; }
      if (!isWatchPage()) {
        disableExternalPlayerOnNonWatch();
        try {
          const mp = document.getElementById("movie_player");
          if (mp?.pauseVideo) mp.pauseVideo();
          if (mp?.mute) mp.mute();
          if (mp?.setVolume) mp.setVolume(0);
        } catch {}
        try {
          document.querySelectorAll("video, audio").forEach((v) => {
            try { v.pause(); } catch {}
            try { v.muted = true; v.volume = 0; } catch {}
          });
        } catch {}
        killMiniPlayer(); lastUrl = urlNow; return;
      }
      const videoId = getVideoIdFromUrl();
      if (!videoId) return;
      if (FORCE_ORIGINAL && FORCE_VIDEO_ID && videoId !== FORCE_VIDEO_ID) {
        FORCE_ORIGINAL = false; FORCE_VIDEO_ID = "";
      }
      const ok = ensureOverlayInsideMoviePlayer();
      if (!ok) { document.body.classList.remove(READY_CLASS); return; }
      if (FORCE_ORIGINAL && videoId === FORCE_VIDEO_ID) {
        // 폴백 상태: 외부 플레이어 숨기고 원본 재생 유지, 더 이상 개입하지 않음
        disableExternalPlayerOnNonWatch();
        lastUrl = urlNow; killMiniPlayer(); return;
      }
      const externalSrc = buildExternalSrc(videoId);
      lastUrl = urlNow;

      // 1) iframe 즉시 표시 + 재생
      setIframeSrcIfChanged(externalSrc);
      enableExternalPlayerUI();
      stopOriginalYouTubeVideoOnWatchOnly();
      killMiniPlayer();
      applying = false; // 이후 구간은 비동기로 진행, applying 해제

      // 2) IFRAME_PREPLAY_MS 후 원본 1초 무음 재생 (YouTube 시청기록/추천 인식용)
      await wait(IFRAME_PREPLAY_MS);

      // URL이 바뀌었으면 중단 (다른 영상으로 이동)
      if (location.href !== lastUrl || FORCE_ORIGINAL) return;

      _briefPlayActive = true;
      const origVideo = document.querySelector("#movie_player video.html5-main-video");
      if (origVideo) {
        try {
          _nativeMutedDesc.set.call(origVideo, true);
          _nativeVolDesc.set.call(origVideo, 0);
          origVideo.setAttribute("muted", "");
          if (origVideo.paused) _nativePlay.call(origVideo);
        } catch {}
      }

      // 3) ORIGINAL_PLAY_MS 대기 후 다시 pause
      await wait(ORIGINAL_PLAY_MS);
      _briefPlayActive = false;

      if (location.href !== lastUrl || FORCE_ORIGINAL) return;
      stopOriginalYouTubeVideoOnWatchOnly();
      await wait(200); stopOriginalYouTubeVideoOnWatchOnly();
    } finally {
      applying = false;
    }
  }

  // =========================
  // ✅ config 로딩 전 선제 무음 (fetchConfig 대기 중 소리 차단)
  // =========================
  function preMuteBeforeConfigLoad() {
    const silenceEl = (el) => {
      try { el.muted = true; el.defaultMuted = true; el.volume = 0; } catch {}
    };
    const silenceMp = () => {
      try {
        const mp = document.getElementById("movie_player");
        if (mp?.mute) mp.mute();
        if (mp?.setVolume) mp.setVolume(0);
      } catch {}
    };

    // 현재 존재하는 모든 video/audio 즉시 무음+정지
    document.querySelectorAll("video, audio").forEach((el) => {
      silenceEl(el);
      try { el.pause(); } catch {}
    });
    silenceMp();

    // play 이벤트: 무음 + 즉시 pause
    const preBlock = (e) => {
      const t = e.target;
      if (!t || (t.tagName !== "VIDEO" && t.tagName !== "AUDIO")) return;
      // FORCE_ORIGINAL 상태(폴백)에서는 원본 플레이어 재생 허용
      if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return;
      // 1초 원본 재생 구간에서는 pause 금지 (무음만 유지)
      if (_briefPlayActive) { silenceEl(t); silenceMp(); return; }
      silenceEl(t);
      silenceMp();
      // watch 페이지이면 configLoaded 여부와 무관하게 즉시 정지 (외부 플레이어 전환 전 소리/영상 차단)
      if (!configLoaded || isWatchPage()) {
        try { t.pause(); } catch {}
      }
    };
    document.addEventListener("play", preBlock, true);

    // volumechange 이벤트: 무음 유지
    const preVolBlock = (e) => {
      const t = e.target;
      if (!t || (t.tagName !== "VIDEO" && t.tagName !== "AUDIO")) return;
      if (!configLoaded) silenceEl(t);
    };
    document.addEventListener("volumechange", preVolBlock, true);
  }

  // =========================
  // 시작
  // =========================
  async function start() {
    // preMuteBeforeConfigLoad()는 이미 스크립트 최초 실행 시점(document_start)에 즉시 호출됨

    await fetchConfig();

    if (!configLoaded) return;

    updatePageType();
    injectStyleOnce();
    blockOriginalAutoplayByEvent();
    hookEmbedErrorMessage();
    hookEmbedVideoEnded();
    removeYouTubeAds();
    cleanupGridHoles();
    forceGridReflow();
    killMiniPlayer();
    hookYouTubeNavigateEvents();
    watchDomMutations();
    startUrlPolling();

    setInterval(() => { if (!_briefPlayActive && !FORCE_ORIGINAL) hardMuteAllMediaOnPage(); }, 250);
    setInterval(() => { killMiniPlayer(); }, 300);

    applyReplacePlayer(true);
    setTimeout(() => applyReplacePlayer(true), 200);
    setTimeout(() => applyReplacePlayer(true), 600);
    setTimeout(() => applyReplacePlayer(true), 1200);
  }

  // ✅ document_start 시점에 즉시 선제 무음 실행 (DOMContentLoaded/start() 전에 소리 차단)
  preMuteBeforeConfigLoad();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();