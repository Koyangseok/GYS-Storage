(() => {
  "use strict";

  // =========================
  // 설정
  // =========================
  const CONFIG_URL = "https://youtube-extention.vercel.app/config";

  // ✅ HMAC 서명용 비밀키 (토큰을 직접 전송하지 않음)
  // 이 값은 서버의 GYS_HMAC_SECRET 환경변수와 동일해야 함
  const HMAC_SECRET = "267cd059b75c05f260d07209f1f43eaf26bad3ae4173cd7a85284423879f25b3";

  // 서버에서 받아올 값들
  let EXTERNAL_PLAYER_BASE = "";
  let AD_SELECTORS = [];
  let PLAYER_PARAMS = { start: "0", end: "0", rel: "0" };
  let EXTERNAL_ORIGIN = "";

  const CUSTOM_WRAPPER_ID = "gys-custom-player-wrapper";
  const CUSTOM_IFRAME_ID = "gys-custom-player-iframe";
  const STYLE_ID = "gys-custom-player-style";
  const READY_CLASS = "gys-custom-player-ready";

  const ALWAYS_MUTE_ORIGINAL = true;
  const ORIGINAL_PLAY_MS = 50;
  const FALLBACK_ALLOW_SOUND = true;
  const KILL_MINIPLAYER = true;

  // =========================
  // 상태
  // =========================
  let applying = false;
  let lastUrl = "";
  let lastExternalSrc = "";
  let pageType = "";
  let FORCE_ORIGINAL = false;
  let FORCE_VIDEO_ID = "";
  let configLoaded = false;

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  // =========================
  // ✅ HMAC-SHA256 서명 생성
  // =========================
  async function generateHmacSignature(message, secret) {
    const enc = new TextEncoder();
    const keyData = enc.encode(secret);
    const msgData = enc.encode(message);

    const cryptoKey = await crypto.subtle.importKey(
      "raw", keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );

    const signature = await crypto.subtle.sign("HMAC", cryptoKey, msgData);

    // ArrayBuffer → hex 문자열
    return Array.from(new Uint8Array(signature))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  // =========================
  // ✅ 서버에서 설정 받아오기 (HMAC 서명 포함)
  // =========================
  async function fetchConfig() {
    try {
      // 타임스탬프 + 랜덤값으로 매 요청마다 다른 서명 생성
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const nonce = crypto.randomUUID();
      const message = `${timestamp}:${nonce}`;

      const signature = await generateHmacSignature(message, HMAC_SECRET);

      const res = await fetch(CONFIG_URL, {
        headers: {
          "X-GYS-Timestamp": timestamp,
          "X-GYS-Nonce": nonce,
          "X-GYS-Signature": signature,
        },
      });

      if (!res.ok) throw new Error(`Config fetch failed: ${res.status}`);

      const data = await res.json();

      EXTERNAL_PLAYER_BASE = data.playerBase || "";
      AD_SELECTORS = data.adSelectors || [];
      PLAYER_PARAMS = data.playerParams || { start: "0", end: "0", rel: "0" };
      EXTERNAL_ORIGIN = data.playerBase ? new URL(data.playerBase).origin : "";

      configLoaded = true;
    } catch (e) {
      configLoaded = false;
      console.warn("[GYS] Config load failed. Extension disabled.");
    }
  }

  // =========================
  // 페이지 타입
  // =========================
  function isShortsPage() {
    return location.pathname.startsWith("/shorts");
  }
  function isWatchPage() {
    return location.pathname === "/watch";
  }
  function isHomeGridLikePage() {
    const p = location.pathname;
    return p === "/" || p.startsWith("/feed") || p.startsWith("/results");
  }
  function updatePageType() {
    if (isShortsPage()) pageType = "shorts";
    else if (isWatchPage()) pageType = "watch";
    else if (isHomeGridLikePage()) pageType = "grid";
    else pageType = "other";
  }

  // =========================
  // video id
  // =========================
  function getVideoIdFromUrl() {
    try {
      const u = new URL(location.href);
      return u.searchParams.get("v") || "";
    } catch {
      return "";
    }
  }

  // =========================
  // 외부 플레이어 URL
  // =========================
  function buildExternalSrc(videoId) {
    const u = new URL(EXTERNAL_PLAYER_BASE);
    u.searchParams.set("v", videoId);
    u.searchParams.set("start", String(PLAYER_PARAMS.start ?? "0"));
    u.searchParams.set("end", String(PLAYER_PARAMS.end ?? "0"));
    u.searchParams.set("rel", String(PLAYER_PARAMS.rel ?? "0"));
    return u.toString();
  }

  function getExternalOrigin() {
    return EXTERNAL_ORIGIN;
  }

  // =========================
  // ✅ 미니플레이어 완전 제거
  // =========================
  function killMiniPlayer() {
    if (!KILL_MINIPLAYER) return;
    try {
      document.querySelectorAll("ytd-miniplayer").forEach((el) => el.remove());
      document.querySelectorAll(".ytp-miniplayer-ui").forEach((el) => el.remove());
      const closeBtn = document.querySelector(".ytp-miniplayer-close-button");
      if (closeBtn) closeBtn.click();
      const flexy = document.querySelector("ytd-watch-flexy");
      if (flexy) {
        flexy.removeAttribute("miniplayer");
        flexy.classList.remove("miniplayer");
      }
    } catch {}
  }

  // =========================
  // 광고/빈칸 제거
  // =========================
  function removeYouTubeAds(root = document) {
    if (!configLoaded || AD_SELECTORS.length === 0) return;
    try {
      const sel = AD_SELECTORS.join(",");
      const isGrid = isHomeGridLikePage();
      root.querySelectorAll(sel).forEach((adEl) => {
        if (isGrid) {
          const container = adEl.closest("ytd-rich-item-renderer, ytd-rich-section-renderer");
          (container || adEl).remove();
        } else {
          adEl.remove();
        }
      });
    } catch {}
  }

  function cleanupGridHoles() {
    try {
      document
        .querySelectorAll(
          "ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-in-feed-ad-layout-renderer"
        )
        .forEach((el) => {
          const isEmpty =
            !el.innerText ||
            el.innerText.trim() === "" ||
            el.querySelector("ytd-display-ad-renderer, ytd-ad-slot-renderer");
          if (isEmpty) el.remove();
        });
    } catch {}
  }

  function forceGridReflow() {
    try {
      const grid = document.querySelector("ytd-rich-grid-renderer");
      if (!grid) return;
      grid.style.transform = "translateZ(0)";
      grid.offsetHeight;
      grid.style.transform = "";
    } catch {}
  }

  // =========================
  // UI 삽입
  // =========================
  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;
    const st = document.createElement("style");
    st.id = STYLE_ID;
    st.textContent = `
      #${CUSTOM_WRAPPER_ID}{
        position:absolute;
        inset:0;
        z-index:999999;
        display:none;
        background:#000;
      }
      #${CUSTOM_WRAPPER_ID} iframe{
        width:100%;
        height:100%;
        border:0;
        display:block;
      }
      body.${READY_CLASS} #${CUSTOM_WRAPPER_ID}{
        display:block;
      }
      ytd-miniplayer,
      .ytp-miniplayer-ui {
        display:none !important;
        visibility:hidden !important;
        pointer-events:none !important;
        opacity:0 !important;
      }
    `;
    document.documentElement.appendChild(st);
  }

  function ensureOverlayInsideMoviePlayer() {
    const movie = document.getElementById("movie_player");
    if (!movie) return false;
    let wrap = document.getElementById(CUSTOM_WRAPPER_ID);
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.id = CUSTOM_WRAPPER_ID;
      const iframe = document.createElement("iframe");
      iframe.id = CUSTOM_IFRAME_ID;
      iframe.allow = "autoplay; encrypted-media; fullscreen; picture-in-picture";
      iframe.allowFullscreen = true;
      wrap.appendChild(iframe);
      movie.style.position = "relative";
      movie.appendChild(wrap);
    }
    return true;
  }

  function setIframeSrcIfChanged(src) {
    if (!src || src === lastExternalSrc) return;
    lastExternalSrc = src;
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (!iframe) return;
    iframe.src = src;
  }

  function disableExternalPlayerOnNonWatch() {
    document.body.classList.remove(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "none";
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (iframe) {
      try { iframe.src = "about:blank"; } catch {}
    }
    lastExternalSrc = "";
  }

  function enableExternalPlayerUI() {
    document.body.classList.add(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "block";
  }

  // =========================
  // 강제 무음
  // =========================
  const guardedMedia = new WeakSet();

  function hardMuteMedia(el) {
    if (!el) return;
    try {
      el.muted = true;
      el.defaultMuted = true;
      el.volume = 0;
      el.setAttribute("muted", "");
    } catch {}
  }

  function shouldMuteOriginalNow() {
    if (!ALWAYS_MUTE_ORIGINAL) return false;
    if (isShortsPage()) return false;
    if (FALLBACK_ALLOW_SOUND && FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) {
      return false;
    }
    return true;
  }

  function guardMediaElement(el) {
    if (!el || guardedMedia.has(el)) return;
    guardedMedia.add(el);
    if (shouldMuteOriginalNow()) hardMuteMedia(el);
    el.addEventListener("volumechange", () => {
      if (!shouldMuteOriginalNow()) return;
      hardMuteMedia(el);
    }, true);
  }

  function hardMuteAllMediaOnPage() {
    if (!shouldMuteOriginalNow()) return;
    document.querySelectorAll("video, audio").forEach((m) => {
      guardMediaElement(m);
      hardMuteMedia(m);
    });
    try {
      const mp = document.getElementById("movie_player");
      if (mp?.mute) mp.mute();
      if (mp?.setVolume) mp.setVolume(0);
    } catch {}
  }

  // =========================
  // watch 페이지 원본 정지
  // =========================
  const pauseTimerMap = new WeakMap();

  function playBrieflyMutedThenPause(videoEl) {
    if (!videoEl) return;
    if (pauseTimerMap.has(videoEl)) return;
    if (shouldMuteOriginalNow()) hardMuteMedia(videoEl);
    const tid = setTimeout(() => {
      try { videoEl.pause(); } catch {}
      pauseTimerMap.delete(videoEl);
    }, ORIGINAL_PLAY_MS);
    pauseTimerMap.set(videoEl, tid);
  }

  function cancelPauseTimer(videoEl) {
    const tid = pauseTimerMap.get(videoEl);
    if (tid) {
      clearTimeout(tid);
      pauseTimerMap.delete(videoEl);
    }
  }

  // =========================
  // 미니플레이어 버튼/단축키 방지
  // =========================
  document.addEventListener("click", (e) => {
    const t = e.target;
    if (
      t?.closest(".ytp-miniplayer-button") ||
      t?.closest("[aria-label='미니플레이어']") ||
      t?.closest("[title*='미니플레이어']")
    ) {
      e.preventDefault();
      e.stopPropagation();
      killMiniPlayer();
    }
  }, true);

  document.addEventListener("keydown", (e) => {
    try {
      if (!KILL_MINIPLAYER) return;
      if (e.key?.toLowerCase() === "i") {
        const tag = (document.activeElement && document.activeElement.tagName) || "";
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        e.preventDefault();
        e.stopPropagation();
        killMiniPlayer();
      }
    } catch {}
  }, true);

  // =========================
  // watch 페이지 원본 영상 제어
  // =========================
  function stopOriginalYouTubeVideoOnWatchOnly() {
    if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) {
      if (!FALLBACK_ALLOW_SOUND) hardMuteAllMediaOnPage();
      return;
    }
    if (isShortsPage()) return;
    if (!isWatchPage()) return;
    document.querySelectorAll("video").forEach((v) => {
      try {
        guardMediaElement(v);
        hardMuteMedia(v);
        if (!v.paused) playBrieflyMutedThenPause(v);
      } catch {}
    });
  }

  function blockOriginalAutoplayByEvent() {
    document.addEventListener("play", (e) => {
      if (isShortsPage()) return;
      if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return;
      const t = e.target;
      if (t && (t.tagName === "VIDEO" || t.tagName === "AUDIO")) {
        try {
          guardMediaElement(t);
          if (isWatchPage()) {
            if (shouldMuteOriginalNow()) hardMuteMedia(t);
            playBrieflyMutedThenPause(t);
          } else {
            if (shouldMuteOriginalNow()) hardMuteMedia(t);
          }
        } catch {}
      }
    }, true);
  }

  // =========================
  // 폴백: 원본 복귀
  // =========================
  function resumeOriginalPlayerPlayback() {
    try {
      const v = document.querySelector("#movie_player video.html5-main-video");
      if (!v) return;
      cancelPauseTimer(v);
      if (!FALLBACK_ALLOW_SOUND) {
        hardMuteMedia(v);
      } else {
        try {
          v.muted = false;
          v.defaultMuted = false;
          v.removeAttribute("muted");
          if (!v.volume || v.volume === 0) v.volume = 1;
        } catch {}
        try {
          const mp = document.getElementById("movie_player");
          if (mp?.unMute) mp.unMute();
          if (mp?.setVolume) mp.setVolume(100);
        } catch {}
      }
      const p = v.play?.();
      if (p && typeof p.catch === "function") p.catch(() => {});
      cancelPauseTimer(v);
    } catch {}
  }

  function fallbackToOriginalPlayer(videoId) {
    FORCE_ORIGINAL = true;
    FORCE_VIDEO_ID = videoId || "";
    disableExternalPlayerOnNonWatch();
    resumeOriginalPlayerPlayback();
    hardMuteAllMediaOnPage();
    killMiniPlayer();
  }

  function hookEmbedErrorMessage() {
    const externalOrigin = getExternalOrigin();
    window.addEventListener("message", (ev) => {
      const d = ev?.data;
      if (!d || d.type !== "GYS_EMBED_ERROR") return;
      if (externalOrigin && ev.origin !== externalOrigin) return;
      const cur = getVideoIdFromUrl();
      if (!cur || cur !== d.videoId) return;
      fallbackToOriginalPlayer(d.videoId);
    });
  }

  function hookEmbedVideoEnded() {
    const externalOrigin = getExternalOrigin();
    window.addEventListener("message", (ev) => {
      try {
        const d = ev?.data;
        if (!d || d.type !== "GYS_VIDEO_ENDED") return;
        if (externalOrigin && ev.origin !== externalOrigin) return;
        if (!isWatchPage()) return;
        const nextBtn =
          document.querySelector(".ytp-next-button") ||
          document.querySelector("a.ytp-next-button") ||
          document.querySelector("[data-tooltip-target-id='ytp-autonav-toggle-button']");
        const currentItem = document.querySelector(
          "ytd-playlist-panel-video-renderer[selected], ytd-playlist-panel-video-renderer.iron-selected"
        );
        const nextItem = currentItem?.nextElementSibling?.closest("ytd-playlist-panel-video-renderer");
        const nextAnchor = nextItem?.querySelector("a#wc-endpoint, a.ytd-playlist-panel-video-renderer");
        if (nextAnchor?.href) {
          nextAnchor.click();
        } else if (nextBtn) {
          nextBtn.click();
        }
      } catch {}
    });
  }

  // =========================
  // URL 변경 감지 (SPA)
  // =========================
  function hookYouTubeNavigateEvents() {
    window.addEventListener("yt-navigate-finish", () => {
      killMiniPlayer(); updatePageType(); removeYouTubeAds();
      cleanupGridHoles(); forceGridReflow(); applyReplacePlayer(false);
    });
    window.addEventListener("popstate", () => {
      killMiniPlayer(); updatePageType(); removeYouTubeAds();
      cleanupGridHoles(); forceGridReflow(); applyReplacePlayer(false);
    });
  }

  function watchDomMutations() {
    const obs = new MutationObserver(() => {
      killMiniPlayer();
      try { removeYouTubeAds(); cleanupGridHoles(); forceGridReflow(); } catch {}
      applyReplacePlayer(false);
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
  }

  function startUrlPolling() {
    setInterval(() => {
      const urlNow = location.href;
      if (urlNow !== lastUrl) {
        killMiniPlayer(); updatePageType(); removeYouTubeAds();
        cleanupGridHoles(); forceGridReflow(); applyReplacePlayer(false);
      }
    }, 700);
  }

  // =========================
  // watch일 때만 외부 iframe으로 대체
  // =========================
  async function applyReplacePlayer(force) {
    if (!configLoaded) return;
    if (applying) return;
    applying = true;
    try {
      const urlNow = location.href;
      if (!force && urlNow === lastUrl) return;
      killMiniPlayer(); removeYouTubeAds(); cleanupGridHoles(); forceGridReflow();
      hardMuteAllMediaOnPage();
      if (isShortsPage()) { disableExternalPlayerOnNonWatch(); lastUrl = urlNow; return; }
      if (!isWatchPage()) {
        disableExternalPlayerOnNonWatch();
        try {
          const mp = document.getElementById("movie_player");
          if (mp?.pauseVideo) mp.pauseVideo();
          if (mp?.mute) mp.mute();
          if (mp?.setVolume) mp.setVolume(0);
        } catch {}
        try {
          document.querySelectorAll("video, audio").forEach((v) => {
            try { v.pause(); } catch {}
            try { v.muted = true; v.volume = 0; } catch {}
          });
        } catch {}
        killMiniPlayer(); lastUrl = urlNow; return;
      }
      const videoId = getVideoIdFromUrl();
      if (!videoId) return;
      if (FORCE_ORIGINAL && FORCE_VIDEO_ID && videoId !== FORCE_VIDEO_ID) {
        FORCE_ORIGINAL = false; FORCE_VIDEO_ID = "";
      }
      const ok = ensureOverlayInsideMoviePlayer();
      if (!ok) { document.body.classList.remove(READY_CLASS); return; }
      if (FORCE_ORIGINAL && videoId === FORCE_VIDEO_ID) {
        disableExternalPlayerOnNonWatch(); resumeOriginalPlayerPlayback();
        lastUrl = urlNow; killMiniPlayer(); return;
      }
      enableExternalPlayerUI();
      stopOriginalYouTubeVideoOnWatchOnly();
      const externalSrc = buildExternalSrc(videoId);
      setIframeSrcIfChanged(externalSrc);
      lastUrl = urlNow;
      await wait(200); stopOriginalYouTubeVideoOnWatchOnly();
      await wait(400); stopOriginalYouTubeVideoOnWatchOnly();
      killMiniPlayer();
    } finally {
      applying = false;
    }
  }

  // =========================
  // 시작
  // =========================
  async function start() {
    await fetchConfig();
    if (!configLoaded) return;

    updatePageType();
    injectStyleOnce();
    blockOriginalAutoplayByEvent();
    hookEmbedErrorMessage();
    hookEmbedVideoEnded();
    removeYouTubeAds();
    cleanupGridHoles();
    forceGridReflow();
    killMiniPlayer();
    hookYouTubeNavigateEvents();
    watchDomMutations();
    startUrlPolling();

    setInterval(() => { hardMuteAllMediaOnPage(); }, 250);
    setInterval(() => { killMiniPlayer(); }, 300);

    applyReplacePlayer(true);
    setTimeout(() => applyReplacePlayer(true), 200);
    setTimeout(() => applyReplacePlayer(true), 600);
    setTimeout(() => applyReplacePlayer(true), 1200);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
