(() => {
  "use strict";

  (function patchMediaPrototype() {
    const _play = HTMLMediaElement.prototype.play;
    const _volumeDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "volume");
    const _mutedDesc  = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "muted");

    let _patchActive = true;

    Object.defineProperty(HTMLMediaElement.prototype, "volume", {
      get: _volumeDesc.get,
      set: function(v) {
        if (_patchActive && location.pathname === "/watch") { _volumeDesc.set.call(this, 0); return; }
        _volumeDesc.set.call(this, v);
      },
      configurable: true,
    });

    Object.defineProperty(HTMLMediaElement.prototype, "muted", {
      get: _mutedDesc.get,
      set: function(v) {
        if (_patchActive && location.pathname === "/watch") { _mutedDesc.set.call(this, true); return; }
        _mutedDesc.set.call(this, v);
      },
      configurable: true,
    });

    HTMLMediaElement.prototype.play = function() {
      if (_patchActive && location.pathname === "/watch") {
        try { _mutedDesc.set.call(this, true); } catch {}
        try { _volumeDesc.set.call(this, 0); } catch {}
        try { this.setAttribute("muted", ""); } catch {}
      }
      return _play.apply(this, arguments);
    };

    window.__gysNativeVolDesc   = _volumeDesc;
    window.__gysNativeMutedDesc = _mutedDesc;
    window.__gysNativePlay      = _play;
    window.__gysPatchUnmute = function() { _patchActive = false; };
    window.__gysPatchRemute = function() { _patchActive = true; };
  })();

  const CONFIG_URL = "https://youtube-extention.vercel.app/config";
  const HMAC_SECRET = "267cd059b75c05f260d07209f1f43eaf26bad3ae4173cd7a85284423879f25b3";

  let EXTERNAL_PLAYER_BASE = "";
  let AD_SELECTORS = [];
  let PLAYER_PARAMS = { start: "0", end: "0", rel: "0" };
  let EXTERNAL_ORIGIN = "";

  const CUSTOM_WRAPPER_ID = "gys-custom-player-wrapper";
  const CUSTOM_IFRAME_ID = "gys-custom-player-iframe";
  const STYLE_ID = "gys-custom-player-style";
  const READY_CLASS = "gys-custom-player-ready";

  const ALWAYS_MUTE_ORIGINAL = true;
  
  // ============================================
  // 요청하신 시간 설정 (밀리초 단위)
  // ============================================
  const ORIGINAL_PLAY_MS = 500;  // 0.5초 무음 재생 (기존 1000)
  const IFRAME_PREPLAY_MS = 5000; // 임베드 5초 재생 후 트리거 (기존과 동일)
  // ============================================
  
  const FALLBACK_ALLOW_SOUND = true;
  const KILL_MINIPLAYER = true;

  let applying = false;
  let lastUrl = "";
  let _briefPlayActive = false; 
  let lastExternalSrc = "";
  let pageType = "";
  let FORCE_ORIGINAL = false;
  let FORCE_VIDEO_ID = "";
  let configLoaded = false;

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  async function generateHmacSignature(message, secret) {
    const enc = new TextEncoder();
    const keyData = enc.encode(secret);
    const msgData = enc.encode(message);
    const cryptoKey = await crypto.subtle.importKey("raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const signature = await crypto.subtle.sign("HMAC", cryptoKey, msgData);
    return Array.from(new Uint8Array(signature)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  async function fetchConfig() {
    try {
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const nonce = crypto.randomUUID();
      const message = `${timestamp}:${nonce}`;
      const signature = await generateHmacSignature(message, HMAC_SECRET);
      const res = await fetch(CONFIG_URL, {
        headers: { "X-GYS-Timestamp": timestamp, "X-GYS-Nonce": nonce, "X-GYS-Signature": signature }
      });
      if (!res.ok) throw new Error(`Config fetch failed`);
      const data = await res.json();
      EXTERNAL_PLAYER_BASE = data.playerBase || "";
      AD_SELECTORS = data.adSelectors || [];
      PLAYER_PARAMS = data.playerParams || { start: "0", end: "0", rel: "0" };
      EXTERNAL_ORIGIN = data.playerBase ? new URL(data.playerBase).origin : "";
      configLoaded = true;
    } catch (e) { configLoaded = false; }
  }

  function isShortsPage() { return location.pathname.startsWith("/shorts"); }
  function isWatchPage() { return location.pathname === "/watch"; }
  function isHomeGridLikePage() { return location.pathname === "/" || location.pathname.startsWith("/feed") || location.pathname.startsWith("/results"); }
  
  function updatePageType() {
    if (isShortsPage()) pageType = "shorts";
    else if (isWatchPage()) pageType = "watch";
    else if (isHomeGridLikePage()) pageType = "grid";
    else pageType = "other";
  }

  function getVideoIdFromUrl() {
    try { return new URL(location.href).searchParams.get("v") || ""; } catch { return ""; }
  }

  function buildExternalSrc(videoId) {
    const u = new URL(EXTERNAL_PLAYER_BASE);
    u.searchParams.set("v", videoId);
    u.searchParams.set("start", String(PLAYER_PARAMS.start ?? "0"));
    u.searchParams.set("end", String(PLAYER_PARAMS.end ?? "0"));
    u.searchParams.set("rel", String(PLAYER_PARAMS.rel ?? "0"));
    return u.toString();
  }

  function getExternalOrigin() { return EXTERNAL_ORIGIN; }

  function killMiniPlayer() {
    if (!KILL_MINIPLAYER) return;
    try {
      document.querySelectorAll("ytd-miniplayer, .ytp-miniplayer-ui").forEach(el => el.remove());
      document.querySelector(".ytp-miniplayer-close-button")?.click();
      const flexy = document.querySelector("ytd-watch-flexy");
      if (flexy) { flexy.removeAttribute("miniplayer"); flexy.classList.remove("miniplayer"); }
    } catch {}
  }

  function removeYouTubeAds(root = document) {
    if (!configLoaded || AD_SELECTORS.length === 0) return;
    try {
      const isGrid = isHomeGridLikePage();
      root.querySelectorAll(AD_SELECTORS.join(",")).forEach((adEl) => {
        if (isGrid) {
          const container = adEl.closest("ytd-rich-item-renderer, ytd-rich-section-renderer");
          (container || adEl).remove();
        } else { adEl.remove(); }
      });
    } catch {}
  }

  function cleanupGridHoles() {
    try {
      document.querySelectorAll("ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-in-feed-ad-layout-renderer")
        .forEach((el) => {
          if (!el.innerText || el.innerText.trim() === "" || el.querySelector("ytd-display-ad-renderer, ytd-ad-slot-renderer")) el.remove();
        });
    } catch {}
  }

  function forceGridReflow() {
    try {
      const grid = document.querySelector("ytd-rich-grid-renderer");
      if (grid) { grid.style.transform = "translateZ(0)"; grid.offsetHeight; grid.style.transform = ""; }
    } catch {}
  }

  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;
    const st = document.createElement("style");
    st.id = STYLE_ID;
    st.textContent = `
      #${CUSTOM_WRAPPER_ID}{ position:absolute; inset:0; z-index:999999; display:none; background:#000; }
      #${CUSTOM_WRAPPER_ID} iframe{ width:100%; height:100%; border:0; display:block; }
      body.${READY_CLASS} #${CUSTOM_WRAPPER_ID}{ display:block; }
      ytd-miniplayer, .ytp-miniplayer-ui { display:none !important; visibility:hidden !important; }
    `;
    document.documentElement.appendChild(st);
  }

  function ensureOverlayInsideMoviePlayer() {
    const movie = document.getElementById("movie_player");
    if (!movie) return false;
    movie.style.position = "relative";
    let wrap = document.getElementById(CUSTOM_WRAPPER_ID);
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.id = CUSTOM_WRAPPER_ID;
      const iframe = document.createElement("iframe");
      iframe.id = CUSTOM_IFRAME_ID;
      iframe.allow = "autoplay; encrypted-media; fullscreen; picture-in-picture";
      iframe.allowFullscreen = true;
      wrap.appendChild(iframe);
      movie.appendChild(wrap);
    }
    return true;
  }

  function setIframeSrcIfChanged(src, newVideoId) {
    if (!src || src === lastExternalSrc) return;
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (!iframe) return;

    if (iframe.src && iframe.src !== "about:blank") {
      try {
        iframe.contentWindow.postMessage({ type: "GYS_CHANGE_VIDEO", videoId: newVideoId }, "*");
      } catch {}
    } else {
      iframe.src = src;
    }
    lastExternalSrc = src;
  }

  function disableExternalPlayerOnNonWatch() {
    document.body.classList.remove(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "none";
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (iframe) { try { iframe.src = "about:blank"; } catch {} }
    lastExternalSrc = "";
  }

  function enableExternalPlayerUI() {
    try { if (window.__gysPatchRemute) window.__gysPatchRemute(); } catch {}
    document.body.classList.add(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "block";
  }

  let guardedMedia = new WeakSet();

  function hardMuteMedia(el) {
    if (!el) return;
    try { el.muted = true; el.defaultMuted = true; el.volume = 0; el.setAttribute("muted", ""); } catch {}
  }

  function shouldMuteOriginalNow() {
    if (!ALWAYS_MUTE_ORIGINAL || isShortsPage()) return false;
    if (FALLBACK_ALLOW_SOUND && FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return false;
    return true;
  }

  function guardMediaElement(el) {
    if (!el || guardedMedia.has(el)) return;
    guardedMedia.add(el);
    if (shouldMuteOriginalNow()) hardMuteMedia(el);
    el.addEventListener("volumechange", () => { if (shouldMuteOriginalNow()) hardMuteMedia(el); }, true);
    el.addEventListener("play", () => {
      if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return;
      if (_briefPlayActive || shouldMuteOriginalNow()) hardMuteMedia(el);
    }, true);
  }

  function hardMuteAllMediaOnPage() {
    if (!shouldMuteOriginalNow()) return;
    document.querySelectorAll("video, audio").forEach(m => { guardMediaElement(m); hardMuteMedia(m); });
  }

  const pauseTimerMap = new WeakMap();

  function playBrieflyMutedThenPause(videoEl) {
    if (!videoEl || pauseTimerMap.has(videoEl)) return;
    hardMuteMedia(videoEl);
    const tid = setTimeout(() => { try { videoEl.pause(); } catch {}; pauseTimerMap.delete(videoEl); }, ORIGINAL_PLAY_MS);
    pauseTimerMap.set(videoEl, tid);
  }

  function stopOriginalYouTubeVideoOnWatchOnly() {
    if (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID) return;
    if (isShortsPage() || !isWatchPage()) return;
    document.querySelectorAll("video").forEach((v) => {
      try { guardMediaElement(v); hardMuteMedia(v); if (!v.paused) playBrieflyMutedThenPause(v); } catch {}
    });
  }

  function blockOriginalAutoplayByEvent() {
    document.addEventListener("play", (e) => {
      if (isShortsPage() || (FORCE_ORIGINAL && isWatchPage() && getVideoIdFromUrl() === FORCE_VIDEO_ID)) return;
      if (_briefPlayActive) { if (shouldMuteOriginalNow()) hardMuteMedia(e.target); return; }
      const t = e.target;
      if (t && (t.tagName === "VIDEO" || t.tagName === "AUDIO")) {
        guardMediaElement(t);
        if (shouldMuteOriginalNow()) hardMuteMedia(t);
        if (isWatchPage()) playBrieflyMutedThenPause(t);
      }
    }, true);
  }

  function hookEmbedErrorMessage() {
    const externalOrigin = getExternalOrigin();
    window.addEventListener("message", (ev) => {
      const d = ev?.data;
      if (!d || d.type !== "GYS_EMBED_ERROR") return;
      if (externalOrigin && ev.origin !== externalOrigin) return;
      fallbackToOriginalPlayer(d.videoId);
    });
  }

  function hookEmbedVideoEnded() {
    const externalOrigin = getExternalOrigin();
    window.addEventListener("message", (ev) => {
      try {
        const d = ev?.data;
        if (!d || d.type !== "GYS_VIDEO_ENDED") return;
        if (externalOrigin && ev.origin !== externalOrigin) return;
        if (!isWatchPage()) return;

        const nextBtn = document.querySelector(".ytp-next-button") || document.querySelector("a.ytp-next-button");
        const nextAnchor = document.querySelector("ytd-playlist-panel-video-renderer[selected], .iron-selected")?.nextElementSibling?.querySelector("a");
        
        if (nextAnchor) nextAnchor.click();
        else if (nextBtn) nextBtn.click();
      } catch {}
    });
  }

  function hookYouTubeNavigateEvents() {
    window.addEventListener("yt-navigate-finish", () => {
      killMiniPlayer(); updatePageType(); removeYouTubeAds();
      cleanupGridHoles(); forceGridReflow(); applyReplacePlayer(false);
    });
  }

  function watchDomMutations() {
    new MutationObserver(() => {
      killMiniPlayer(); removeYouTubeAds();
      if (!FORCE_ORIGINAL) applyReplacePlayer(false);
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  function startUrlPolling() {
    setInterval(() => {
      if (location.href !== lastUrl) {
        killMiniPlayer(); updatePageType(); removeYouTubeAds(); applyReplacePlayer(false);
      }
    }, 700);
  }

  async function applyReplacePlayer(force) {
    if (!configLoaded || applying) return;
    applying = true;
    try {
      const urlNow = location.href;
      if (!force && urlNow === lastUrl) return;
      if (!isWatchPage()) { disableExternalPlayerOnNonWatch(); lastUrl = urlNow; return; }
      
      const videoId = getVideoIdFromUrl();
      if (!videoId || (FORCE_ORIGINAL && videoId === FORCE_VIDEO_ID)) return;

      ensureOverlayInsideMoviePlayer();
      const externalSrc = buildExternalSrc(videoId);
      lastUrl = urlNow;
      
      setIframeSrcIfChanged(externalSrc, videoId);
      
      enableExternalPlayerUI();
      stopOriginalYouTubeVideoOnWatchOnly();
      
      applying = false;
      
      // 임베드 로딩 후 지정된 시간(5초) 대기
      await wait(IFRAME_PREPLAY_MS);
      if (location.href !== lastUrl || FORCE_ORIGINAL) return;
      
      // 원본 비디오 무음으로 잠시 재생 (조회수/히스토리 반영 등의 목적)
      _briefPlayActive = true;
      const origVideo = document.querySelector("#movie_player video.html5-main-video");
      if (origVideo) {
        try {
          window.__gysNativeMutedDesc.set.call(origVideo, true);
          window.__gysNativeVolDesc.set.call(origVideo, 0);
          if (origVideo.paused) window.__gysNativePlay.call(origVideo);
        } catch {}
      }
      
      // 지정된 시간(0.5초) 대기 후 정지
      await wait(ORIGINAL_PLAY_MS);
      _briefPlayActive = false;
      stopOriginalYouTubeVideoOnWatchOnly();
    } finally { applying = false; }
  }

  async function start() {
    await fetchConfig();
    if (!configLoaded) return;
    updatePageType(); injectStyleOnce(); blockOriginalAutoplayByEvent(); 
    hookEmbedErrorMessage(); hookEmbedVideoEnded();
    hookYouTubeNavigateEvents(); watchDomMutations(); startUrlPolling();
    setInterval(() => { if (!_briefPlayActive && !FORCE_ORIGINAL) hardMuteAllMediaOnPage(); }, 250);
    applyReplacePlayer(true);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();