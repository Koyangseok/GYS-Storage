// 전역 변수
let allHistory = [];
let currentUser = null;

// ==================== 썸네일 IndexedDB (로컬) ====================
const THUMB_DB_NAME = 'gys_thumb_db_v1';
const THUMB_STORE = 'thumbs';
// background.js와 동일한 버전으로 맞춰야 VersionError가 나지 않습니다.
// v2: priority 인덱스가 추가됨
const THUMB_DB_VERSION = 2;

function openThumbDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(THUMB_DB_NAME, THUMB_DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(THUMB_STORE)) {
        const store = db.createObjectStore(THUMB_STORE, { keyPath: 'thumbKey' });
        store.createIndex('updatedAt', 'updatedAt');
        // v2: priority 인덱스(읽기에는 필수 아님, 버전 정합성 유지용)
        store.createIndex('priority', 'priority');
      }
      // 기존 스토어가 이미 있으면(업그레이드) priority 인덱스만 추가
      else {
        const store = req.transaction.objectStore(THUMB_STORE);
        if (!store.indexNames.contains('priority')) {
          store.createIndex('priority', 'priority');
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getThumbBlob(thumbKey) {
  if (!thumbKey) return null;
  const db = await openThumbDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(THUMB_STORE, 'readonly');
    const req = tx.objectStore(THUMB_STORE).get(thumbKey);
    req.onsuccess = () => resolve(req.result ? req.result.blob : null);
    req.onerror = () => reject(req.error);
  });
}

async function attachThumbnail(containerEl, thumbKey) {
  if (!containerEl) return;
  const img = containerEl.querySelector('img.thumbnail');
  if (!img) return;

  try {
    const blob = await getThumbBlob(thumbKey);
    if (!blob) return;

    const url = URL.createObjectURL(blob);
    img.src = url;
    img.onload = () => URL.revokeObjectURL(url);
  } catch (e) {
    console.warn('[Popup] 썸네일 로드 실패(무시):', e);
  }
}

const firebaseConfig = {
  apiKey: "AIzaSyBY5TF2rXxDhnOzKc7-Kj_ZdZgMroI7XSo",
  authDomain: "gys-viewing-history.firebaseapp.com",
  projectId: "gys-viewing-history",
  storageBucket: "gys-viewing-history.firebasestorage.app",
  messagingSenderId: "359356108676",
  appId: "1:359356108676:web:f25fad4471e2404d1d17d1",
  measurementId: "G-OSX2WVH7H8"
};

// 초기화
document.addEventListener('DOMContentLoaded', async () => {
  console.log('[Popup] 초기화 시작');
  
  // 명시적으로 로딩 화면만 표시
  const loadingScreen = document.getElementById('loadingScreen');
  const loginScreen = document.getElementById('loginScreen');
  const mainScreen = document.getElementById('mainScreen');
  
  if (loadingScreen) loadingScreen.style.display = 'flex';
  if (loginScreen) loginScreen.style.display = 'none';
  if (mainScreen) mainScreen.style.display = 'none';
  
  console.log('[Popup] 로딩 화면 표시 완료');
  
  // Firebase 초기화
  try {
    if (typeof firebase !== 'undefined' && (!firebase.apps || firebase.apps.length === 0)) {
      firebase.initializeApp(firebaseConfig);
      console.log('[Popup] Firebase 초기화 완료');
    }
  } catch (error) {
    console.error('[Popup] Firebase 초기화 실패:', error);
  }
  
  // 사용자 인증 상태 확인
  await checkAuthState();
  
  // 이벤트 리스너 등록
  setupEventListeners();
});

// 인증 상태 확인
async function checkAuthState() {
  try {
    console.log('[Popup] 인증 상태 확인 시작');
    
    // 최소 대기 시간 (로딩 화면을 최소 500ms는 보여줌)
    const minLoadingTime = 500;
    const startTime = Date.now();
    
    // Firebase가 로드될 때까지 기다림
    let retries = 0;
    const maxRetries = 20; // 최대 3초 (150ms * 20)
    let authChecked = false;
    
    while (retries < maxRetries && !authChecked) {
      const response = await chrome.runtime.sendMessage({ type: 'getCurrentUser' });
      
      // response가 있고 ready가 true이면 인증 확인 완료
      if (response && response.ready === true) {
        currentUser = response.user;
        authChecked = true;
        
        console.log('[Popup] 인증 확인 완료:', currentUser ? '로그인됨' : '비로그인');
        
        // 최소 로딩 시간 보장
        const elapsedTime = Date.now() - startTime;
        if (elapsedTime < minLoadingTime) {
          await new Promise(resolve => setTimeout(resolve, minLoadingTime - elapsedTime));
        }
        
        if (currentUser) {
          console.log('[Popup] 로그인 상태:', currentUser.email);
          showMainScreen();
          loadHistory();
        } else {
          console.log('[Popup] 비로그인 상태');
          showLoginScreen();
        }
        return;
      }
      
      // 150ms 대기 후 재시도
      await new Promise(resolve => setTimeout(resolve, 150));
      retries++;
      console.log('[Popup] 재시도 중...', retries, '/', maxRetries);
    }
    
    // 최대 재시도 후에도 실패하면 로그인 화면 표시
    console.log('[Popup] Firebase 초기화 대기 시간 초과 - 로그인 화면 표시');
    
    // 최소 로딩 시간 보장
    const elapsedTime = Date.now() - startTime;
    if (elapsedTime < minLoadingTime) {
      await new Promise(resolve => setTimeout(resolve, minLoadingTime - elapsedTime));
    }
    
    showLoginScreen();
  } catch (error) {
    console.error('[Popup] 인증 상태 확인 실패:', error);
    showLoginScreen();
  }
}

// 로딩 화면 표시
function showLoadingScreen() {
  const loadingScreen = document.getElementById('loadingScreen');
  const loginScreen = document.getElementById('loginScreen');
  const mainScreen = document.getElementById('mainScreen');
  if (loadingScreen) loadingScreen.style.display = 'flex';
  if (loginScreen) loginScreen.style.display = 'none';
  if (mainScreen) mainScreen.style.display = 'none';
}

// 로그인 화면 표시
function showLoginScreen() {
  const loadingScreen = document.getElementById('loadingScreen');
  const loginScreen = document.getElementById('loginScreen');
  const mainScreen = document.getElementById('mainScreen');
  if (loadingScreen) loadingScreen.style.display = 'none';
  if (loginScreen) loginScreen.style.display = 'block';
  if (mainScreen) mainScreen.style.display = 'none';
}

// 메인 화면 표시
function showMainScreen() {
  const loadingScreen = document.getElementById('loadingScreen');
  const loginScreen = document.getElementById('loginScreen');
  const mainScreen = document.getElementById('mainScreen');
  if (loadingScreen) loadingScreen.style.display = 'none';
  if (loginScreen) loginScreen.style.display = 'none';
  if (mainScreen) mainScreen.style.display = 'block';
  
  // 로그인 상태 UI 업데이트
  if (currentUser) {
    const userBtn = document.getElementById('userButton');
    const syncBtn = document.getElementById('syncButton');
    const userEmail = document.getElementById('userEmail');
    
    if (userBtn) userBtn.style.display = 'block';
    if (syncBtn) syncBtn.style.display = 'block';
    if (userEmail) userEmail.textContent = currentUser.email;
  }
}

// 이벤트 리스너 설정
function setupEventListeners() {
  // 로그인/회원가입 탭
  document.getElementById('loginTab')?.addEventListener('click', () => {
    document.getElementById('loginTab').classList.add('active');
    document.getElementById('signupTab').classList.remove('active');
    document.getElementById('loginForm').style.display = 'flex';
    document.getElementById('signupForm').style.display = 'none';
  });
  
  document.getElementById('signupTab')?.addEventListener('click', () => {
    document.getElementById('signupTab').classList.add('active');
    document.getElementById('loginTab').classList.remove('active');
    document.getElementById('signupForm').style.display = 'flex';
    document.getElementById('loginForm').style.display = 'none';
  });
  
  // 로그인 폼
  document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    await handleLogin(email, password);
  });
  
  // 회원가입 폼
  document.getElementById('signupForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const passwordConfirm = document.getElementById('signupPasswordConfirm').value;
    
    if (password !== passwordConfirm) {
      showError('signupError', '비밀번호가 일치하지 않습니다.');
      return;
    }
    
    await handleSignup(email, password);
  });
  
  // 사용자 버튼
  document.getElementById('userButton')?.addEventListener('click', (e) => {
    e.stopPropagation(); // 이벤트 버블링 방지
    const menu = document.getElementById('userMenu');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
  });
  
  // 메뉴 외부 클릭 시 닫기
  document.addEventListener('click', (e) => {
    const menu = document.getElementById('userMenu');
    const userButton = document.getElementById('userButton');
    
    // 클릭한 요소가 버튼 내부(SVG 포함)인지 확인
    const clickedInsideButton = e.target.closest('#userButton');
    const clickedInsideMenu = menu && menu.contains(e.target);
    
    if (menu && !clickedInsideButton && !clickedInsideMenu) {
      menu.style.display = 'none';
    }
  });
  
  // 로그아웃
  document.getElementById('logoutButton')?.addEventListener('click', async () => {
    await handleLogout();
  });
  
  // 동기화 버튼
  document.getElementById('syncButton')?.addEventListener('click', async () => {
    await syncWithCloud();
  });
  
  // 검색
  document.getElementById('searchInput')?.addEventListener('input', (e) => {
    filterHistory(e.target.value);
  });
  
  // 전체 삭제
  document.getElementById('clearAll')?.addEventListener('click', () => {
    if (confirm('모든 시청 기록을 삭제하시겠습니까?')) {
      clearAllHistory();
    }
  });
}

// 로그인 처리
async function handleLogin(email, password) {
  try {
    const loginBtn = document.querySelector('#loginForm button');
    if(loginBtn) {
        loginBtn.textContent = '로그인 중...';
        loginBtn.disabled = true;
    }
    
    const response = await chrome.runtime.sendMessage({
      type: 'signIn',
      email,
      password
    });
    
    if (response && response.success) {
      console.log('[Popup] 로그인 성공');
      currentUser = response.user;
      showMainScreen();
      loadHistory();
    } else {
      showError('loginError', getErrorMessage(response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('[Popup] 로그인 에러:', error);
    showError('loginError', '로그인 중 오류가 발생했습니다.');
  } finally {
    const loginBtn = document.querySelector('#loginForm button');
    if(loginBtn) {
        loginBtn.textContent = '로그인';
        loginBtn.disabled = false;
    }
  }
}

// 회원가입 처리
async function handleSignup(email, password) {
  try {
    const signupBtn = document.querySelector('#signupForm button');
    if(signupBtn) {
        signupBtn.textContent = '가입 중...';
        signupBtn.disabled = true;
    }
    
    const response = await chrome.runtime.sendMessage({
      type: 'signUp',
      email,
      password
    });
    
    if (response && response.success) {
      console.log('[Popup] 회원가입 성공');
      currentUser = response.user;
      showMainScreen();
      loadHistory();
    } else {
      showError('signupError', getErrorMessage(response ? response.error : 'Unknown error'));
    }
  } catch (error) {
    console.error('[Popup] 회원가입 에러:', error);
    showError('signupError', '회원가입 중 오류가 발생했습니다.');
  } finally {
    const signupBtn = document.querySelector('#signupForm button');
    if(signupBtn) {
        signupBtn.textContent = '회원가입';
        signupBtn.disabled = false;
    }
  }
}

// 로그아웃 처리
async function handleLogout() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'signOut' });
    
    if (response && response.success) {
      console.log('[Popup] 로그아웃 성공');
      currentUser = null;
      document.getElementById('userMenu').style.display = 'none';
      showLoginScreen();
    }
  } catch (error) {
    console.error('[Popup] 로그아웃 에러:', error);
    alert('로그아웃 중 오류가 발생했습니다.');
  }
}

// 클라우드 동기화
async function syncWithCloud() {
  const syncBtn = document.getElementById('syncButton');
  if(syncBtn) syncBtn.classList.add('syncing');
  
  try {
    await chrome.runtime.sendMessage({ type: 'syncFromCloud' });
    await loadHistory();
    console.log('[Popup] 동기화 완료');
  } catch (error) {
    console.error('[Popup] 동기화 실패:', error);
    alert('동기화 중 오류가 발생했습니다.');
  } finally {
    if(syncBtn) syncBtn.classList.remove('syncing');
  }
}

// 에러 메시지 표시
function showError(elementId, message) {
  const errorElement = document.getElementById(elementId);
  if (errorElement) {
      errorElement.textContent = message;
      errorElement.style.display = 'block';
      
      setTimeout(() => {
        errorElement.style.display = 'none';
      }, 5000);
  }
}

// 에러 메시지 한글화
function getErrorMessage(error) {
  const errorMessages = {
    'auth/email-already-in-use': '이미 사용 중인 이메일입니다.',
    'auth/invalid-email': '유효하지 않은 이메일 주소입니다.',
    'auth/weak-password': '비밀번호가 너무 약합니다. (최소 6자)',
    'auth/user-not-found': '존재하지 않는 계정입니다.',
    'auth/wrong-password': '잘못된 비밀번호입니다.',
    'auth/too-many-requests': '너무 많은 시도가 있었습니다. 잠시 후 다시 시도해주세요.'
  };
  
  return errorMessages[error] || error || '알 수 없는 오류가 발생했습니다.';
}

// 시청 기록 불러오기
async function loadHistory() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'getWatchHistory' });
    allHistory = (response && response.history) ? response.history : [];
    
    displayHistory(allHistory);
  } catch (error) {
    console.error('[Popup] 히스토리 로드 실패:', error);
  }
}

// 시청 기록 표시
function displayHistory(history) {
  const historyList = document.getElementById('historyList');
  const emptyState = document.getElementById('emptyState');
  
  if (!historyList || !emptyState) return;

  if (history.length === 0) {
    historyList.style.display = 'none';
    emptyState.style.display = 'flex';
    return;
  }
  
  historyList.style.display = 'block';
  emptyState.style.display = 'none';
  historyList.innerHTML = '';
  
  history.forEach(item => {
    const historyItem = createHistoryItem(item);
    historyList.appendChild(historyItem);

    // 썸네일은 Firestore가 아닌 로컬 IndexedDB(Blob)에서 로드
    // (blob URL을 저장하지 않고, 렌더링 시점에만 createObjectURL)
    attachThumbnail(historyItem, item.thumbKey);
  });
}

// [수정된 부분] 시청 기록 아이템 생성 (X 버튼 클릭 이벤트 분리)
function createHistoryItem(item) {
  const div = document.createElement('div');
  div.className = 'history-item';
  
  // 1. 전체 영역 클릭 시 비디오 열기 (JS로 등록)
  div.addEventListener('click', () => {
    openVideo(item.url, item.currentTime);
  });
  
  const thumbnailHtml = `<img src="" alt="썸네일" class="thumbnail">`
  
  const episodeHtml = item.episode ? `<div class="history-episode">${item.episode}</div>` : '';
  
  const currentMinutes = Math.floor(item.currentTime / 60);
  const currentSeconds = item.currentTime % 60;
  const durationMinutes = Math.floor(item.duration / 60);
  const durationSeconds = item.duration % 60;
  
  const timeString = `${currentMinutes}:${currentSeconds.toString().padStart(2, '0')} / ${durationMinutes}:${durationSeconds.toString().padStart(2, '0')}`;
  
  const lastWatchedDate = new Date(item.lastWatched);
  const now = new Date();
  const diffMs = now - lastWatchedDate;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  let timeAgo;
  if (diffMins < 1) timeAgo = '방금 전';
  else if (diffMins < 60) timeAgo = `${diffMins}분 전`;
  else if (diffHours < 24) timeAgo = `${diffHours}시간 전`;
  else timeAgo = `${diffDays}일 전`;
  
  // 2. HTML 구조 (onclick 속성 제거함)
  div.innerHTML = `
    <div class="thumbnail-wrapper">
      ${thumbnailHtml}
      <div class="progress-bar">
        <div class="progress-fill" style="width: ${item.progress}%"></div>
      </div>
    </div>
    <div class="history-content">
      <div class="history-title">${item.title}</div>
      ${episodeHtml}
      <div class="history-time">
        ${timeString}
        <span class="history-progress">${item.progress}%</span>
        <span style="margin-left: 8px; color: #555;">• ${timeAgo}</span>
      </div>
    </div>
    <button class="btn-delete">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  `;
  
  // 3. 삭제 버튼 클릭 이벤트 별도 등록 (stopPropagation 적용)
  const deleteBtn = div.querySelector('.btn-delete');
  if (deleteBtn) {
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation(); // 부모(div) 클릭 이벤트 막기
        deleteHistory(item.id);
      });
  }
  
  return div;
}

// 검색 필터
function filterHistory(searchTerm) {
  const filtered = allHistory.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (item.episode && item.episode.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  displayHistory(filtered);
}

// 비디오 열기
function openVideo(url, currentTime) {
  chrome.tabs.create({ url }, (tab) => {
    setTimeout(() => {
      chrome.tabs.sendMessage(tab.id, {
        type: 'seekToTime',
        time: currentTime
      });
    }, 2000);
  });
}

// [수정] 기록 삭제 후 즉시 Firebase 동기화
async function deleteHistory(id) {
  try {
    await chrome.runtime.sendMessage({
      type: 'deleteHistory',
      id: id
    });
    
    // Firebase 동기화 추가
    if (currentUser) {
      await chrome.runtime.sendMessage({ type: 'syncToCloud' });
      console.log('[Popup] 삭제 후 Firebase 동기화 완료');
    }
    
    await loadHistory();
  } catch (error) {
    console.error('[Popup] 삭제 실패:', error);
  }
}

// [수정] 전체 삭제 후 즉시 Firebase 동기화
async function clearAllHistory() {
  try {
    await chrome.runtime.sendMessage({ type: 'clearAllHistory' });
    
    // Firebase 동기화 추가
    if (currentUser) {
      await chrome.runtime.sendMessage({ type: 'syncToCloud' });
      console.log('[Popup] 전체 삭제 후 Firebase 동기화 완료');
    }
    
    await loadHistory();
  } catch (error) {
    console.error('[Popup] 전체 삭제 실패:', error);
  }
}