(function() {
    const WORKER_URL = 'https://gysadblock.rhdidtjr123.workers.dev/';

    function injectStyles(selectors) {
        if (!selectors || selectors.length === 0) return;
        let styleTag = document.getElementById('gys-block-style');
        if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = 'gys-block-style';
            (document.head || document.documentElement).appendChild(styleTag);
        }
        styleTag.innerHTML = `
            ${selectors.join(', ')} {
                display: none !important;
                height: 0 !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        `;
    }

    // 수정: iframe.src를 이미 교체했는지 추적 (페이지당 한 번만 교체)
    let iframeReplaced = false;

    function runRemovalLogic(config) {
        config.adSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => el.remove());
        });

        if (window.location.hostname.includes('tvwiki')) {
            const iframe = document.getElementById('view_iframe');
            if (iframe) {
                const playerUrl = iframe.getAttribute('data-player' + config.preferredPlayer);
                // 아직 교체하지 않았고 실제로 다른 URL일 때만 한 번만 교체
                if (playerUrl && !iframeReplaced && iframe.src !== playerUrl) {
                    iframeReplaced = true;
                    iframe.src = playerUrl;
                }
            }
        }
    }

    async function initialize() {
        chrome.storage.local.get(['adConfig'], (result) => {
            if (result.adConfig) {
                injectStyles(result.adConfig.adSelectors);
                runRemovalLogic(result.adConfig);
            }
        });

        try {
            const response = await fetch(WORKER_URL);
            const config = await response.json();

            injectStyles(config.adSelectors);
            chrome.storage.local.set({ adConfig: config });

            // 수정: MutationObserver는 광고 요소 제거만 담당
            // iframe.src 교체는 포함하지 않음 - 영상 중간에 리로드되는 현상 방지
            const observer = new MutationObserver(() => {
                config.adSelectors.forEach(selector => {
                    document.querySelectorAll(selector).forEach(el => el.remove());
                });
            });
            observer.observe(document.documentElement, { childList: true, subtree: true });

            runRemovalLogic(config);
        } catch (e) {
            console.error("GYS Blocker Error:", e);
        }
    }

    initialize();
})();