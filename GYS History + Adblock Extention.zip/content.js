// 비디오 플레이어 감지 및 시청 기록 저장
let saveInterval;
let currentVideoElement = null;
let notificationShown = false;


// 문자열 해시(FNV-1a 32bit) - thumbKey 생성용
function hashString(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    // h *= 16777619 (32bit overflow)
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return ('00000000' + h.toString(16)).slice(-8);
}

// tvwiki 관련 사이트인지 확인
function isTvwikiSite() {
  const url = window.location.href.toLowerCase();
  const hostname = window.location.hostname.toLowerCase();
  
  // tvwiki 관련 도메인 또는 vercel.app에서 tvwiki 컨텐츠를 보여주는 경우
  // anilife.app 추가
  return hostname.includes('tvwiki') || 
         url.includes('tvwiki') ||
         hostname.includes('vercel.app') ||
         hostname.includes('anilife.app') ||
         hostname.includes('anilife');
}

function showNotification(message) {
  // 화면 우측 상단에 알림 표시
  const notification = document.createElement('div');
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #4a9eff;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    animation: slideIn 0.3s ease-out;
  `;
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(400px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.transition = 'opacity 0.3s';
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

function init() {
  // tvwiki 관련 사이트가 아니면 실행하지 않음
  if (!isTvwikiSite()) {
    console.log('[시청기록] tvwiki/anilife 사이트가 아님 - 종료');
    return;
  }
  
  console.log('[시청기록] 확장 프로그램 초기화 시작');
  console.log('[시청기록] 현재 사이트:', window.location.hostname);
  
  // 즉시 비디오 찾기
  findAndTrackVideo();
  
  // 0.5초 후 다시 시도
  setTimeout(findAndTrackVideo, 500);
  
  // 1초 후 다시 시도 (DOM 완전 로드 대기)
  setTimeout(findAndTrackVideo, 1000);
  
  // 2초 후 다시 시도
  setTimeout(findAndTrackVideo, 2000);
  
  // 3초 후 다시 시도 (비디오 플레이어 로드 대기)
  setTimeout(findAndTrackVideo, 3000);
  
  // 5초 후 다시 시도
  setTimeout(findAndTrackVideo, 5000);
  
  // 7초 후 다시 시도 (느린 연결 대응)
  setTimeout(findAndTrackVideo, 7000);
  
  // 10초 후 다시 시도 (마지막 시도)
  setTimeout(findAndTrackVideo, 10000);
  
  // 이후 주기적으로 비디오 찾기 (새로 로드되는 경우 대응)
  setInterval(() => {
    if (!currentVideoElement) {
      findAndTrackVideo();
    }
  }, 5000);
  
  // 페이지 변경 감지 (SPA 대응)
  observePageChanges();
  
  // MutationObserver로 DOM 변경 감지 - 더 적극적으로
  const observer = new MutationObserver((mutations) => {
    // video 태그가 추가되었는지 확인
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) { // Element 노드
          if (node.tagName === 'VIDEO' || node.querySelector?.('video')) {
            console.log('[시청기록] 새로운 video 태그 감지됨!');
            setTimeout(findAndTrackVideo, 100);
            return;
          }
        }
      }
    }
    
    // 기존 로직
    if (!currentVideoElement) {
      setTimeout(findAndTrackVideo, 500);
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  console.log('[시청기록] MutationObserver 설정 완료');
}

function findAndTrackVideo() {
  let video = null;
  
  console.log('[시청기록] 비디오 검색 시작...');
  
  // 전략 1: 일반 video 태그
  video = document.querySelector('video');
  if (video) console.log('[시청기록] 전략1: 일반 video 태그 발견');
  
  // 전략 2: 모든 iframe 검사 (same-origin만 가능)
  if (!video) {
    const iframes = document.querySelectorAll('iframe');
    console.log('[시청기록] 전략2: iframe 검색 중... (' + iframes.length + '개)');
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          video = iframeDoc.querySelector('video');
          if (video) {
            console.log('[시청기록] iframe 내부에서 video 발견');
            break;
          }
        }
      } catch (e) {
        // Cross-origin iframe
        console.log('[시청기록] Cross-origin iframe 접근 불가:', iframe.src);
      }
    }
  }
  
  // 전략 3: Shadow DOM 검사 (재귀적 탐색)
  if (!video) {
    console.log('[시청기록] 전략3: Shadow DOM 검색 중...');
    
    function findVideoInShadow(root) {
      const video = root.querySelector('video');
      if (video) return video;
      
      const allElements = root.querySelectorAll('*');
      for (const el of allElements) {
        if (el.shadowRoot) {
          const found = findVideoInShadow(el.shadowRoot);
          if (found) return found;
        }
      }
      return null;
    }
    
    video = findVideoInShadow(document);
    if (video) console.log('[시청기록] Shadow DOM에서 video 발견');
  }
  
  // 전략 4: 깊은 iframe 검사 (중첩된 iframe)
  if (!video) {
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          const nestedIframes = iframeDoc.querySelectorAll('iframe');
          for (const nested of nestedIframes) {
            try {
              const nestedDoc = nested.contentDocument || nested.contentWindow?.document;
              if (nestedDoc) {
                video = nestedDoc.querySelector('video');
                if (video) {
                  console.log('[시청기록] 중첩 iframe에서 video 발견');
                  break;
                }
              }
            } catch (e) {}
          }
          if (video) break;
        }
      } catch (e) {}
    }
  }
  
  // 전략 5: 모든 video 요소 찾기 (display:none 포함)
  if (!video) {
    const allVideos = document.querySelectorAll('video');
    if (allVideos.length > 0) {
      console.log('[시청기록] 전략5: 숨겨진 video 포함 검색 (' + allVideos.length + '개 발견)');
      // 가장 큰 비디오 찾기 (실제 플레이어일 가능성이 높음)
      let largestVideo = null;
      let maxSize = 0;
      
      allVideos.forEach(v => {
        const size = v.videoWidth * v.videoHeight;
        if (size > maxSize || (v.duration > 0 && !largestVideo)) {
          maxSize = size;
          largestVideo = v;
        }
      });
      
      video = largestVideo || allVideos[0];
    }
  }
  
  // 전략 6: HLS 플레이어 대응 - Artplayer, Plyr, Video.js 등
  if (!video) {
    console.log('[시청기록] 전략6: HLS 플레이어 컨테이너 검색 중...');
    const playerSelectors = [
      '.art-video-player video',
      '.artplayer video',
      '.plyr video',
      '.video-js video',
      '[class*="player"] video',
      '[id*="player"] video',
      '[class*="video"] video',
      '[id*="video"] video'
    ];
    
    for (const selector of playerSelectors) {
      video = document.querySelector(selector);
      if (video) {
        console.log('[시청기록] HLS 플레이어에서 video 발견:', selector);
        break;
      }
    }
  }
  
  // 전략 7: 동적 로딩 대기 - MutationObserver로 나중에 추가될 video 감지
  if (!video) {
    console.log('[시청기록] 전략7: 동적 video 로딩 대기 중...');
    // 이 경우 아래 observer가 감지할 것임
  }
  
  if (video && video !== currentVideoElement) {
    console.log('[시청기록] ✅ 새로운 비디오 발견! 추적 시작');
    console.log('[시청기록] 비디오 정보:');
    console.log('  - duration:', video.duration);
    console.log('  - src:', video.src || video.currentSrc || '(없음)');
    console.log('  - readyState:', video.readyState);
    console.log('  - videoWidth:', video.videoWidth);
    console.log('  - videoHeight:', video.videoHeight);
    currentVideoElement = video;
    setupVideoTracking(video);
  } else if (!video) {
    console.log('[시청기록] ❌ 비디오를 찾을 수 없습니다');
    console.log('[시청기록] 페이지 정보:');
    console.log('  - URL:', window.location.href);
    console.log('  - Hostname:', window.location.hostname);
    console.log('  - iframes:', document.querySelectorAll('iframe').length + '개');
    console.log('  - Shadow DOM 요소:', Array.from(document.querySelectorAll('*')).filter(el => el.shadowRoot).length + '개');
  }
}

function setupVideoTracking(video) {
  // 기존 인터벌 제거
  if (saveInterval) {
    clearInterval(saveInterval);
  }
  
  let hasRestoredPosition = false;
  let restoreAttempted = false;
  
  // 저장된 위치 복원 시도 함수
  const attemptRestore = () => {
    if (!restoreAttempted) {
      restoreAttempted = true;
      restoreSavedPosition(video, () => {
        hasRestoredPosition = true;
      });
    }
  };
  
  // 방법 1: 재생 이벤트에서 복원
  video.addEventListener('play', () => {
    if (!hasRestoredPosition) {
      attemptRestore();
    }
    saveCurrentWatchState(video);
  });
  
  // 방법 2: 시간 업데이트 시작 시 복원 (자동재생 대응)
  video.addEventListener('timeupdate', function onFirstTimeUpdate() {
    if (video.currentTime > 0 && video.currentTime < 3 && !hasRestoredPosition) {
      // 재생이 시작되었지만 아직 복원 안됨
      attemptRestore();
    }
    
    // 복원 후에는 이 리스너 제거
    if (hasRestoredPosition) {
      video.removeEventListener('timeupdate', onFirstTimeUpdate);
    }
  });
  
  // 방법 3: 비디오가 이미 재생 중인 경우 (페이지 로드 시 자동재생)
  setTimeout(() => {
    if (!video.paused && video.currentTime > 0 && !hasRestoredPosition) {
      attemptRestore();
    }
  }, 100);
  
  // 10초마다 시청 정보 저장
  saveInterval = setInterval(() => {
    if (!video.paused && video.currentTime > 0) {
      saveCurrentWatchState(video);
    }
  }, 10000);
  
  // 일시정지 시 저장
  video.addEventListener('pause', () => {
    saveCurrentWatchState(video);
  });
  
  // 시간 업데이트 시 저장 (첫 재생 감지)
  video.addEventListener('timeupdate', function onTimeUpdate() {
    if (video.currentTime > 0) {
      saveCurrentWatchState(video);
      video.removeEventListener('timeupdate', onTimeUpdate);
    }
  });
  
  // 페이지 떠날 때 저장
  window.addEventListener('beforeunload', () => {
    saveCurrentWatchState(video);
  });
}

// 저장된 시청 위치 복원 함수
function restoreSavedPosition(video, callback) {
  console.log('[시청기록] 복원 시도 시작');
  
  // background script에서 현재 탭의 URL 가져오기
  chrome.runtime.sendMessage({
    type: 'getTabInfo'
  }, (response) => {
    const currentUrl = response?.url || window.location.href;
    const currentTitle = response?.title ? cleanTabTitle(response.title) : '';
    const currentEpisode = extractEpisode();
    
    console.log('[시청기록] 현재 페이지 정보:');
    console.log('  - URL:', currentUrl);
    console.log('  - 제목:', currentTitle);
    console.log('  - 에피소드:', currentEpisode);
  
  // storage에서 시청 기록 가져오기
  chrome.storage.local.get(['watchHistory'], (result) => {
    const history = result.watchHistory || [];
    
    console.log('[시청기록] 전체 저장된 기록 개수:', history.length);
    
    // 디버깅: 모든 저장된 기록 출력
    if (history.length > 0) {
      console.log('[시청기록] 저장된 기록 목록:');
      history.slice(0, 5).forEach((item, idx) => {
        console.log(`  [${idx}]`);
        console.log(`       제목: ${item.title}`);
        console.log(`       에피소드: ${item.episode || '없음'}`);
        console.log(`       URL: ${item.url}`);
        console.log(`       시간: ${item.currentTime}초 / ${item.duration}초`);
      });
    }
    
    // 1순위: URL 정확히 일치 (Anilife는 UUID로 고유하므로 가장 확실함)
    let savedRecord = history.find(item => item.url === currentUrl);
    
    if (savedRecord) {
      console.log('[시청기록] ✅ URL 정확히 일치로 기록 발견!');
      console.log('  - 저장된 URL:', savedRecord.url);
      console.log('  - 현재 URL:', currentUrl);
      console.log('  - 일치:', savedRecord.url === currentUrl);
    } else {
      console.log('[시청기록] ⚠️ URL 일치하는 기록 없음');
      console.log('  - 현재 URL:', currentUrl);
      
      // 2순위: uniqueKey로 찾기
      const currentUniqueKey = currentEpisode ? `${currentTitle} - ${currentEpisode}` : currentTitle;
      savedRecord = history.find(item => item.uniqueKey === currentUniqueKey);
      
      if (savedRecord) {
        console.log('[시청기록] ✅ uniqueKey 일치로 기록 발견:', currentUniqueKey);
      }
    }
    
    // 정확히 일치하는 게 없으면 URL의 일부가 일치하는지 확인
    // (단, id 파라미터가 있는 경우는 제외 - Anilife 같은 사이트는 id로 구분해야 함)
    if (!savedRecord) {
      const urlParams = new URLSearchParams(new URL(currentUrl).search);
      const hasIdParam = urlParams.has('id');

      // ✅ FIX: season/episode(또는 ep) 같은 "에피소드 구분 파라미터"가 있으면
      //         쿼리 제거 후 유사 URL 매칭을 하면 서로 다른 화가 섞이므로 금지
      const hasEpisodeParam =
        urlParams.has('episode') ||
        urlParams.has('season') ||
        urlParams.has('ep');
      
      if (!hasIdParam && !hasEpisodeParam) {
        console.log('[시청기록] 정확히 일치하는 URL 없음, 유사 URL 검색 중...');
        
        // URL에서 쿼리 파라미터 제거하고 비교
        const currentUrlBase = currentUrl.split('?')[0];
        savedRecord = history.find(item => {
          const itemUrlBase = item.url.split('?')[0];
          return itemUrlBase === currentUrlBase;
        });
        
        if (savedRecord) {
          console.log('[시청기록] 유사 URL 발견:', savedRecord.url);
        }
      } else {
        console.log('[시청기록] id/season/episode 파라미터가 있는 URL - 정확한 매칭만 수행');
      }
    }
    
    console.log('[시청기록] 매칭된 저장 기록:', savedRecord);
    
    if (savedRecord && savedRecord.currentTime > 0) {
      const savedTime = savedRecord.currentTime;
      
      console.log('[시청기록] 저장된 시간:', savedTime + '초');
      
      // 복원 시도 함수
      const doRestore = () => {
        // duration이 유효하게 로드될 때까지 대기
        if (!video.duration || isNaN(video.duration) || video.duration === 0) {
          console.log('[시청기록] duration 로딩 중... 현재값:', video.duration, 'readyState:', video.readyState);
          return false; // 아직 준비 안됨
        }
        
        const duration = video.duration;
        const progress = (savedTime / duration) * 100;
        
        console.log('[시청기록] ✓ duration 로드 완료:', duration + '초');
        console.log('[시청기록] 진행률:', progress.toFixed(2) + '%', '저장위치:', savedTime + '초');
        
        // 진행률이 5% 이상 95% 미만인 경우에만 복원 (처음이나 끝부분은 제외)
        if (progress >= 5 && progress < 95) {
          console.log('[시청기록] 복원 조건 충족! 복원 시도...');
          console.log('[시청기록] 현재위치:', video.currentTime + '초', '목표위치:', savedTime + '초');
          console.log('[시청기록] 비디오 상태 - readyState:', video.readyState, 'paused:', video.paused);
          
          // 현재 위치가 저장된 위치와 많이 다르면 복원
          if (Math.abs(video.currentTime - savedTime) > 5) {
            const beforeTime = video.currentTime;
            
            try {
              video.currentTime = savedTime;
              console.log('[시청기록] ▶ 위치 변경 명령 실행:', beforeTime + '초', '→', savedTime + '초');
              
              // 1초 후 실제로 변경되었는지 확인
              setTimeout(() => {
                const actualTime = video.currentTime;
                console.log('[시청기록] 변경 후 실제 위치:', actualTime + '초');
                console.log('[시청기록] 목표 위치와의 차이:', Math.abs(actualTime - savedTime) + '초');
                
                if (Math.abs(actualTime - savedTime) < 5) {
                  console.log('[시청기록] ✅ 복원 성공!');
                  // 사용자에게 알림
                  const minutes = Math.floor(savedTime / 60);
                  const seconds = Math.floor(savedTime % 60);
                  const timeStr = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                  showNotification(`이전 시청 위치(${timeStr})로 이동했습니다`);
                } else {
                  console.log('[시청기록] ❌ 복원 실패 - 플레이어가 시간 변경을 거부했습니다');
                  console.log('[시청기록] 이 플레이어는 currentTime 변경을 지원하지 않는 것 같습니다');
                }
              }, 1000);
            } catch (error) {
              console.error('[시청기록] ❌ 복원 중 오류:', error);
            }
            
            if (callback) callback();
            return true; // 복원 완료
          } else {
            console.log('[시청기록] 이미 올바른 위치에 있음 (차이:', Math.abs(video.currentTime - savedTime) + '초)');
            if (callback) callback();
            return true;
          }
        } else {
          console.log('[시청기록] 진행률이 복원 범위를 벗어남:', progress.toFixed(2) + '% (5%~95% 사이만 복원)');
          if (callback) callback();
          return true;
        }
      };
      
      // duration 로드를 기다리면서 여러 번 시도
      let attempts = 0;
      const maxAttempts = 20; // 최대 10초 대기 (0.5초 x 20)
      
      const tryRestore = () => {
        attempts++;
        console.log('[시청기록] 복원 시도 #' + attempts + ' / ' + maxAttempts);
        
        if (doRestore()) {
          console.log('[시청기록] 복원 프로세스 완료');
          return;
        }
        
        // 아직 준비 안되었으면 재시도
        if (attempts < maxAttempts) {
          setTimeout(tryRestore, 500);
        } else {
          console.log('[시청기록] ❌ duration 로드 타임아웃 - 복원 포기');
          console.log('[시청기록] 최종 duration 값:', video.duration);
          if (callback) callback();
        }
      };
      
      // 즉시 시도
      tryRestore();
      
      // loadedmetadata 이벤트도 감지
      video.addEventListener('loadedmetadata', () => {
        console.log('[시청기록] 🔔 loadedmetadata 이벤트 발생 - duration:', video.duration);
        if (attempts < 3) { // 아직 시도 초반이면 다시 시도
          setTimeout(tryRestore, 100);
        }
      }, { once: true });
      
      // durationchange 이벤트도 감지
      video.addEventListener('durationchange', () => {
        console.log('[시청기록] 🔔 durationchange 이벤트 발생 - duration:', video.duration);
        if (attempts < 3) {
          setTimeout(tryRestore, 100);
        }
      }, { once: true });
      
    } else {
      console.log('[시청기록] ⚠ 저장된 기록이 없거나 시간이 0초입니다');
      console.log('[시청기록] savedRecord:', savedRecord);
      console.log('[시청기록] currentTime:', savedRecord?.currentTime);
      if (callback) callback();
    }
  });
  }); // getTabInfo 콜백 닫기
}

function saveCurrentWatchState(video) {
  try {
    const episode = extractEpisode();
    const thumbSource = extractThumbnail();
    const currentTime = Math.floor(video.currentTime);
    const duration = Math.floor(video.duration);
    const progress = Math.floor((currentTime / duration) * 100);
    
    // duration이 유효하지 않으면 저장 안함
    if (!duration || isNaN(duration) || duration === 0) {
      return;
    }
    
    // background script에 탭 정보(제목과 URL) 요청
    chrome.runtime.sendMessage({
      type: 'getTabInfo'
    }, (response) => {
      // URL을 그대로 사용 (쿼리 파라미터 포함)
      const pageUrl = response?.url || window.location.href;
      const fullTitle = response?.title || document.title || '제목 없음';

      // 썸네일은 Firestore/ChromeStorage에 넣지 않고, background(확장 IndexedDB)에 저장
      // 우선순위:
      //   3) <video> 프레임 캡처(가장 정확) > 2) 페이지에서 얻은 thumbSource(dataURL/URL) > 1) 탭 캡처 크롭(폴백)
      // 같은 thumbKey로 여러 저장이 발생해도, 낮은 우선순위가 높은 우선순위를 덮어쓰지 않도록 합니다.
      const thumbKey = 't_' + hashString(pageUrl);
      let thumbSaved = false;

      // 0) (가장 정확) <video> 프레임을 직접 캡처해서 썸네일 생성
      //    - 성공하면 사이트 UI/사이드바가 섞일 일이 없음
      //    - CORS/보호된 스트림이면 toDataURL 단계에서 예외가 나며, 그때는 아래(탭 캡처)로 폴백
      try {
        if (video && video.videoWidth && video.videoHeight) {
          const targetW = 320;
          const ratio = video.videoHeight / video.videoWidth;
          const targetH = Math.max(180, Math.round(targetW * ratio));
          const canvas = document.createElement('canvas');
          canvas.width = targetW;
          canvas.height = targetH;
          const ctx = canvas.getContext('2d', { willReadFrequently: false });
          if (ctx) {
            ctx.drawImage(video, 0, 0, targetW, targetH);
            // JPEG로 압축(로컬 저장이므로 품질/용량 균형)
            const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
            if (dataUrl && dataUrl.startsWith('data:image/')) {
              thumbSaved = true;
              chrome.runtime.sendMessage({
                type: 'saveThumbnail',
                thumbKey,
                source: dataUrl,
                priority: 3
              });
            }
          }
        }
      } catch (e) {
        // 보호된 스트림/교차 출처(CORS) 등으로 캔버스가 taint되면 예외가 날 수 있음
        // 이 경우 아래의 captureVisibleTab(탭 캡처)로 폴백
        // console.log('[시청기록] video frame capture failed, fallback to tab capture', e);
      }

      // 1) thumbSource가 data:image 또는 http(s) URL이면 그대로 저장 시도
      if (!thumbSaved && thumbSource && (thumbSource.startsWith('data:image/') || thumbSource.startsWith('http://') || thumbSource.startsWith('https://'))) {
        thumbSaved = true;
        chrome.runtime.sendMessage({
          type: 'saveThumbnail',
          thumbKey,
          source: thumbSource,
          priority: 2
        });
      }

      // 2) 비디오(플레이어) 영역 스크린샷 캡처(가장 안정적)
      //    - captureVisibleTab은 '보이는 뷰포트'만 캡처하므로, rect는 뷰포트 기준 좌표여야 합니다.
      //    - 페이지 줌/비주얼뷰포트(모바일/줌) 오프셋을 반영해 정확히 '플레이어'만 크롭합니다.
      try {
        // 이미 더 정확한 썸네일(비디오 프레임/페이지 썸네일)을 저장했다면 탭 캡처 폴백은 생략
        if (thumbSaved) {
          // do nothing
        } else {
        // 탭 캡처(captureVisibleTab)로 크롭할 때는 '컨테이너'가 아니라
        // 실제 <video> 요소의 rect를 기준으로 잡는 게 가장 정확합니다.
        // (컨테이너는 레이아웃/사이드바를 포함하는 경우가 많아 오차가 발생)
        const el = video;
        const rect0 = (el && el.getBoundingClientRect) ? el.getBoundingClientRect() : null;

        // visualViewport 오프셋(줌/모바일) 보정
        const vv = window.visualViewport;
        const vx = vv && typeof vv.offsetLeft === 'number' ? vv.offsetLeft : 0;
        const vy = vv && typeof vv.offsetTop === 'number' ? vv.offsetTop : 0;

        if (rect0 && rect0.width > 40 && rect0.height > 40) {
          const rect = {
            x: (rect0.left ?? rect0.x) + vx,
            y: (rect0.top ?? rect0.y) + vy,
            width: rect0.width,
            height: rect0.height
          };

          // 캡처 타이밍이 너무 빠르면 검은 프레임이 찍힐 수 있어 살짝 지연
          setTimeout(() => {
            chrome.runtime.sendMessage({
              type: 'captureVisibleThumbnail',
              thumbKey,
              rect,
              dpr: window.devicePixelRatio || 1,
              vw: window.innerWidth || 0,
              vh: window.innerHeight || 0,
              priority: 1
            });
          }, 200);
        }
        }
      } catch (e) {
        // ignore
      }

      
      // 탭 제목에서 필요한 부분만 정리
      let title = fullTitle;
      
      // 탭 제목 정리 로직
      title = cleanTabTitle(title);
      
      // 만약 탭 제목에서 제대로 추출되지 않으면 다른 방법 시도
      if (!title || title === '제목 없음' || title.length < 3) {
        title = extractFromDOM() || '제목 없음';
      }
      
      // 비디오 src도 수집
      const videoSrc = video.src || video.currentSrc || '';
      
      // 1순위: 제목에서 직접 에피소드 추출
      const titleEpMatch = fullTitle.match(/(\d+)\s*화/);
      const extractedEp = titleEpMatch ? `${titleEpMatch[1]}화` : episode;
      
      // Anilife의 경우 UUID가 있으므로 URL이 이미 고유함
      // uniqueKey는 사람이 읽기 쉽게 "제목 - 에피소드" 형식으로
      let uniqueKey = '';
      if (extractedEp) {
        uniqueKey = `${title} - ${extractedEp}`;
      } else {
        // 에피소드 추출 실패 시 URL의 id 파라미터 사용
        const urlParams = new URLSearchParams(new URL(pageUrl).search);
        const videoId = urlParams.get('id');
        if (videoId) {
          uniqueKey = `${title} - [${videoId.substring(0, 8)}]`;
        } else {
          uniqueKey = pageUrl; // URL 자체를 사용
        }
      }
      
      console.log('[시청기록] 저장 시도:');
      console.log('  - 원본 탭 제목:', fullTitle);
      console.log('  - 정리된 제목:', title);
      console.log('  - 에피소드:', extractedEp || '(없음)');
      console.log('  - 고유키:', uniqueKey);
      console.log('  - URL:', pageUrl);
      console.log('  - 시간:', currentTime + '초 / ' + duration + '초');
      
      const data = {
        title,
        episode: extractedEp || '',
        url: pageUrl, // 전체 URL 저장 (쿼리 파라미터 포함)
        uniqueKey,
        thumbKey,
        currentTime,
        duration,
        progress
      };
      
      console.log('[시청기록] 최종 저장 데이터:', JSON.stringify(data, null, 2));
      
      chrome.runtime.sendMessage({
        type: 'saveWatchHistory',
        data
      });
    });
  } catch (error) {
    console.error('[시청기록] 저장 중 오류:', error);
  }
}

// 탭 제목 정리
function cleanTabTitle(title) {
  if (!title) return '';
  
  let cleaned = title.trim();
  
  // 일반적인 패턴들 제거
  const patternsToRemove = [
    // 티비위키 관련
    /\s*[-|]\s*티비위키.*$/i,
    /\s*[-|]\s*tvwiki.*$/i,
    /\s*[-|]\s*티비위키\s*•\s*.*$/i,
    
    // Anilife 관련
    /\s*[-|]\s*Anilife.*$/i,
    /\s*[-|]\s*anilife.*$/i,
    /\s*[-|]\s*애니라이프.*$/i,
    
    // 기타 플레이어/사이트 이름
    /\s*[-|]\s*시청.*$/i,
    /\s*[-|]\s*재생.*$/i,
    /\s*[-|]\s*플레이어.*$/i,
    /\s*[-|]\s*Player.*$/i,
    
    // 브라우저 기본 접미사
    /\s*[-|]\s*.+\.(com|net|app|kr).*$/i,
  ];
  
  patternsToRemove.forEach(pattern => {
    cleaned = cleaned.replace(pattern, '');
  });
  
  // 양쪽 공백 제거
  cleaned = cleaned.trim();
  
  // 만약 제목이 너무 짧으면 원본 제목 반환
  if (cleaned.length < 2) {
    return title.trim();
  }
  
  return cleaned;
}

// DOM에서 제목 추출 (백업 방법)
function extractFromDOM() {
  // h1 태그에서 제목 찾기
  const h1 = document.querySelector('h1');
  if (h1) {
    const h1Text = h1.textContent.trim();
    if (h1Text && h1Text.length > 3) {
      console.log('[시청기록] h1에서 제목 발견:', h1Text);
      return cleanTabTitle(h1Text);
    }
  }
  
  // og:title 메타 태그
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle && ogTitle.content) {
    const ogText = ogTitle.content.trim();
    if (ogText && ogText.length > 3) {
      console.log('[시청기록] og:title에서 제목 발견:', ogText);
      return cleanTabTitle(ogText);
    }
  }
  
  // title 요소
  const titleEl = document.querySelector('title');
  if (titleEl) {
    const titleText = titleEl.textContent.trim();
    if (titleText && titleText.length > 3) {
      return cleanTabTitle(titleText);
    }
  }
  
  // video-title 클래스
  const videoTitle = document.querySelector('.video-title, .title, .episode-title');
  if (videoTitle) {
    const videoText = videoTitle.textContent.trim();
    if (videoText && videoText.length > 3) {
      console.log('[시청기록] video-title에서 제목 발견:', videoText);
      return cleanTabTitle(videoText);
    }
  }
  
  return null;
}

function extractEpisode() {
  const url = window.location.href;
  const pathname = window.location.pathname;
  const hash = window.location.hash;
  const pageTitle = document.title;
  
  console.log('[시청기록] 에피소드 추출 시도:', {
    url,
    pathname,
    hash,
    title: pageTitle
  });
  
  // 1. Anilife.app 전용: 페이지 제목에서 추출 (가장 확실한 방법)
  if (url.includes('anilife')) {
    // "작품명 - 3화" 또는 "3화 - 작품명" 형식
    const titleEpMatch = pageTitle.match(/(\d+)\s*화/);
    if (titleEpMatch) {
      console.log('[시청기록] ✅ Anilife 페이지 제목에서 에피소드 발견:', titleEpMatch[1] + '화');
      return `${titleEpMatch[1]}화`;
    }
    
    // DOM에서 에피소드 정보 찾기 - Anilife 특화
    const anilifeSel = [
      '.episode-title', '.ep-title', '.current-episode',
      '[class*="episode"]', '[class*="ep-"]',
      'h1', 'h2', '.title', '.video-title'
    ];
    
    for (const selector of anilifeSel) {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        const text = el.textContent || el.innerText || '';
        const epMatch = text.match(/(\d+)\s*화/);
        if (epMatch) {
          console.log('[시청기록] ✅ Anilife DOM에서 에피소드 발견:', epMatch[1] + '화', '(셀렉터:', selector + ')');
          return `${epMatch[1]}화`;
        }
      }
    }
    
    // URL 해시에서 추출 (#/watch/123 형식)
    const hashMatch = hash.match(/\/watch\/(\d+)/i) || 
                      hash.match(/\/episode\/(\d+)/i) ||
                      hash.match(/\/(\d+)/);
    if (hashMatch) {
      console.log('[시청기록] Anilife 해시에서 에피소드 발견:', hashMatch[1]);
      return `${hashMatch[1]}화`;
    }
    
    // 쿼리 파라미터에서 추출
    const urlParams = new URLSearchParams(window.location.search);
    const epParam = urlParams.get('ep') || urlParams.get('episode') || urlParams.get('id');
    if (epParam) {
      console.log('[시청기록] Anilife 쿼리에서 에피소드 발견:', epParam);
      return `${epParam}화`;
    }
    
    // pathname에서 추출
    const pathMatch = pathname.match(/\/(?:watch|episode)\/(\d+)/i);
    if (pathMatch) {
      console.log('[시청기록] Anilife 경로에서 에피소드 발견:', pathMatch[1]);
      return `${pathMatch[1]}화`;
    }
    
    // 마지막 수단: body의 모든 텍스트에서 "X화" 패턴 찾기
    const bodyText = document.body.innerText;
    const bodyMatch = bodyText.match(/(\d+)\s*화/);
    if (bodyMatch) {
      console.log('[시청기록] ⚠️ Body 텍스트에서 에피소드 발견 (불확실):', bodyMatch[1] + '화');
      return `${bodyMatch[1]}화`;
    }
  }
  
  // 2. tvwiki: /world/10182 형식
  const worldMatch = pathname.match(/\/world\/(\d+)/i);
  if (worldMatch) {
    console.log('[시청기록] tvwiki 경로에서 에피소드 발견:', worldMatch[1]);
    return `${worldMatch[1]}화`;
  }
  
  // 3. 일반적인 ep, episode 패턴 찾기 (URL 전체)
  const episodeMatch = url.match(/[?&#\/](?:ep|episode)[=\/]?(\d+)/i);
  if (episodeMatch) {
    console.log('[시청기록] URL에서 에피소드 발견:', episodeMatch[1]);
    return `${episodeMatch[1]}화`;
  }
  
  // 4. 페이지 내용에서 에피소드 찾기
  const episodeElement = document.querySelector('[class*="episode"], [class*="ep"], [data-episode]');
  if (episodeElement) {
    const epText = episodeElement.getAttribute('data-episode') || episodeElement.textContent.trim();
    const epMatch = epText.match(/(\d+)/);
    if (epMatch) {
      console.log('[시청기록] DOM 요소에서 에피소드 발견:', epMatch[1]);
      return `${epMatch[1]}화`;
    }
  }
  
  // 5. h1, h2 태그에서 "X화" 패턴 찾기
  const headings = document.querySelectorAll('h1, h2, h3');
  for (const heading of headings) {
    const match = heading.textContent.match(/(\d+)\s*화/);
    if (match) {
      console.log('[시청기록] 제목에서 에피소드 발견:', match[1]);
      return match[0];
    }
  }
  
  console.log('[시청기록] ❌ 에피소드를 찾을 수 없음');
  return '';
}

function extractThumbnail() {
  // 1. 비디오에서 직접 스크린샷 캡처
  const video = document.querySelector('video');
  if (video && video.readyState >= 2) {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 320;
      canvas.height = video.videoHeight || 180;
      
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // canvas를 base64 이미지로 변환
      const thumbnail = canvas.toDataURL('image/jpeg', 0.7);
      return thumbnail;
    } catch (e) {
      // CORS 에러 등으로 실패하면 다음 방법 시도
    }
  }
  
  // 2. og:image 메타 태그
  const ogImage = document.querySelector('meta[property="og:image"]');
  if (ogImage) {
    return ogImage.content;
  }
  
  // 3. 페이지 내 썸네일 이미지
  const thumbnail = document.querySelector('.thumbnail img, .poster img, [class*="thumb"] img');
  if (thumbnail) {
    return thumbnail.src;
  }
  
  return '';
}

function observePageChanges() {
  // URL 변경 감지 (SPA)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(() => {
        findAndTrackVideo();
      }, 1000);
    }
  }).observe(document, { subtree: true, childList: true });
}

// 초기화
function startInit() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
  // window load 이벤트에서도 실행 (모든 리소스 로드 완료 후)
  window.addEventListener('load', () => {
    setTimeout(findAndTrackVideo, 500);
    setTimeout(findAndTrackVideo, 2000);
  });
}

// 즉시 실행
startInit();

// 메시지 수신 - 팝업에서 특정 시간으로 이동 요청
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'seekToTime') {
    const video = document.querySelector('video') || currentVideoElement;
    if (video) {
      video.currentTime = message.time;
      video.play();
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, error: 'Video not found' });
    }
  }
});
