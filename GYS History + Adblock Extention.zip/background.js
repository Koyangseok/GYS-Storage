// ==================== 1. Firebase 라이브러리 로드 ====================
importScripts(
  'firebase-app-compat.js',
  'firebase-auth-compat.js',
  'firebase-firestore-compat.js'
);

// ==================== 2. Firebase 설정 및 초기화 ====================
const firebaseConfig = {
  apiKey: "AIzaSyBY5TF2rXxDhnOzKc7-Kj_ZdZgMroI7XSo",
  authDomain: "gys-viewing-history.firebaseapp.com",
  projectId: "gys-viewing-history",
  storageBucket: "gys-viewing-history.firebasestorage.app",
  messagingSenderId: "359356108676",
  appId: "1:359356108676:web:f25fad4471e2404d1d17d1",
  measurementId: "G-OSX2WVH7H8"
};

if (!firebase.apps || firebase.apps.length === 0) {
  firebase.initializeApp(firebaseConfig);
  console.log('[Firebase] 초기화 완료');
}

// 로그인 상태 지속성 설정 (LOCAL = 브라우저 닫아도 유지)
firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL)
  .then(() => {
    console.log('[Firebase] 로그인 상태 지속성 설정 완료 (LOCAL)');
  })
  .catch((error) => {
    console.error('[Firebase] 로그인 상태 지속성 설정 실패:', error);
  });

let currentUser = null;
let authReady = false;

firebase.auth().onAuthStateChanged((user) => {
  currentUser = user;
  authReady = true;
  if (user) {
    console.log('[Firebase] 로그인 상태:', user.email);
    syncFromCloud();
  } else {
    console.log('[Firebase] 로그아웃 상태');
  }
});

// ==================== 3. Firebase 인증 함수 ====================

async function signUp(email, password) {
  try {
    const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
    return { success: true, user: serializeUser(userCredential.user) };
  } catch (error) {
    console.error('[Firebase] 회원가입 실패:', error);
    return { success: false, error: error.code };
  }
}

async function signIn(email, password) {
  try {
    const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
    await syncFromCloud();
    return { success: true, user: serializeUser(userCredential.user) };
  } catch (error) {
    console.error('[Firebase] 로그인 실패:', error);
    return { success: false, error: error.code };
  }
}

async function signOut() {
  try {
    await firebase.auth().signOut();
    currentUser = null;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.code };
  }
}

function getCurrentUser() {
  // Firebase 인증이 아직 준비되지 않았으면 null 반환하지 않고 대기 필요
  if (!authReady) {
    return null; // popup에서 재시도할 것임
  }
  const user = firebase.auth().currentUser;
  return user ? serializeUser(user) : null;
}

function serializeUser(user) {
  if (!user) return null;
  return { uid: user.uid, email: user.email, displayName: user.displayName };
}

// ==================== 4. Firestore 데이터 관리 ====================

async function saveToCloud(watchHistory) {
  try {
    const user = firebase.auth().currentUser;
    if (!user) return { success: false, error: '로그인이 필요합니다.' };
    
    await firebase.firestore().collection('users').doc(user.uid).set({
      email: user.email,
      watchHistory: watchHistory,
      lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error('[Firebase] 저장 실패:', error);
    return { success: false, error: error.message };
  }
}

async function loadFromCloud() {
  try {
    const user = firebase.auth().currentUser;
    if (!user) return { success: false, error: '로그인이 필요합니다.' };
    
    const doc = await firebase.firestore().collection('users').doc(user.uid).get();
    return { success: true, data: doc.exists ? doc.data().watchHistory : [] };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function syncToCloud() {
  const result = await chrome.storage.local.get('watchHistory');
  if (result.watchHistory) await saveToCloud(result.watchHistory);
}

async function syncFromCloud() {
  const result = await loadFromCloud();
  if (result.success && result.data) {
    await chrome.storage.local.set({ watchHistory: result.data });
  }
}

// ==================== 5. 메시지 리스너 ====================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'signUp') { 
    signUp(message.email, message.password).then(sendResponse); 
    return true; 
  }
  if (message.type === 'signIn') { 
    signIn(message.email, message.password).then(sendResponse); 
    return true; 
  }
  if (message.type === 'signOut') { 
    signOut().then(sendResponse); 
    return true; 
  }
  if (message.type === 'getCurrentUser') {
    // authReady가 false면 아직 초기화 중이므로 undefined가 아닌 명확한 응답
    if (!authReady) {
      console.log('[Background] Firebase 인증 초기화 중... (authReady: false)');
      sendResponse({ user: null, ready: false });
    } else {
      const user = getCurrentUser();
      console.log('[Background] getCurrentUser 응답:', user ? user.email : 'null');
      sendResponse({ user: user, ready: true });
    }
    return true;
  }
  if (message.type === 'getTabInfo') {
    if (sender.tab && sender.tab.id) {
      chrome.tabs.get(sender.tab.id, (tab) => {
        sendResponse({
          url: tab.url || '',
          title: tab.title || ''
        });
      });
      return true;
    } else {
      sendResponse({ url: '', title: '' });
    }
    return true;
  }
  if (message.type === 'saveWatchHistory') { 
    saveWatchHistory(message.data).then(() => sendResponse({ success: true })); 
    return true; 
  }
  if (message.type === 'getWatchHistory') { 
    getWatchHistory().then(history => sendResponse({ history })); 
    return true; 
  }
  if (message.type === 'deleteHistory') { 
    deleteHistory(message.id).then(() => sendResponse({ success: true })); 
    return true; 
  }
  if (message.type === 'clearAllHistory') { 
    clearAllHistory().then(() => sendResponse({ success: true })); 
    return true; 
  }
  if (message.type === 'syncToCloud') { 
    syncToCloud().then(() => sendResponse({ success: true })); 
    return true; 
  }
  if (message.type === 'syncFromCloud') { 
    syncFromCloud().then(() => sendResponse({ success: true })); 
    return true; 
  }
});

// ==================== 6. 시청 기록 관리 핵심 로직 ====================

async function saveWatchHistory(data) {
  const history = await getWatchHistory();
  let existingIndex = history.findIndex(item => item.url === data.url);
  
  const historyItem = { ...data, id: data.url, lastWatched: Date.now() };
  
  if (existingIndex >= 0) history[existingIndex] = historyItem;
  else history.unshift(historyItem);
  
  const limitedHistory = history.slice(0, 100);
  await chrome.storage.local.set({ watchHistory: limitedHistory });
  
  // 로그인 상태면 자동으로 Firebase 동기화
  if (currentUser) {
    console.log('[Background] 시청기록 저장 완료 - Firebase 동기화 시작');
    await saveToCloud(limitedHistory);
    console.log('[Background] Firebase 동기화 완료');
  }
}

async function getWatchHistory() {
  const result = await chrome.storage.local.get('watchHistory');
  return (result.watchHistory || []).sort((a, b) => b.lastWatched - a.lastWatched);
}

async function deleteHistory(id) {
  const history = await getWatchHistory();
  const filtered = history.filter(item => item.id !== id);
  await chrome.storage.local.set({ watchHistory: filtered });
  if (currentUser) await saveToCloud(filtered);
}

async function clearAllHistory() {
  await chrome.storage.local.set({ watchHistory: [] });
  if (currentUser) await saveToCloud([]);
}

console.log('[Background] Service Worker Ready');