// ==================== 1. Firebase 라이브러리 로드 ====================
importScripts(
  'firebase-app-compat.js',
  'firebase-auth-compat.js',
  'firebase-firestore-compat.js'
);

// ==================== 2. Firebase 설정 및 초기화 ====================
const firebaseConfig = {
  apiKey: "AIzaSyBY5TF2rXxDhnOzKc7-Kj_ZdZgMroI7XSo",
  authDomain: "gys-viewing-history.firebaseapp.com",
  projectId: "gys-viewing-history",
  storageBucket: "gys-viewing-history.firebasestorage.app",
  messagingSenderId: "359356108676",
  appId: "1:359356108676:web:f25fad4471e2404d1d17d1",
  measurementId: "G-OSX2WVH7H8"
};

if (!firebase.apps || firebase.apps.length === 0) {
  firebase.initializeApp(firebaseConfig);
  console.log('[Firebase] 초기화 완료');
}

// 로그인 상태 지속성 설정 (LOCAL = 브라우저 닫아도 유지)
firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL)
  .then(() => console.log('[Firebase] 로그인 상태 지속성 설정 완료 (LOCAL)'))
  .catch((error) => console.error('[Firebase] 로그인 상태 지속성 설정 실패:', error));

let currentUser = null;
let authReady = false;

firebase.auth().onAuthStateChanged((user) => {
  currentUser = user;
  authReady = true;
  if (user) {
    console.log('[Firebase] 로그인 상태:', user.email);
    syncFromCloud();
  } else {
    console.log('[Firebase] 로그아웃 상태');
  }
});

// ==================== 3. IndexedDB (썸네일 로컬 저장) ====================
// Firestore 1MB 제한을 피하기 위해 썸네일은 Firestore/ChromeStorage에 저장하지 않고,
// extension origin의 IndexedDB에 Blob으로 저장합니다.

const THUMB_DB_NAME = 'gys_thumb_db_v1';
const THUMB_STORE = 'thumbs';
const THUMB_DB_VERSION = 1;

function openThumbDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(THUMB_DB_NAME, THUMB_DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(THUMB_STORE)) {
        const store = db.createObjectStore(THUMB_STORE, { keyPath: 'thumbKey' });
        store.createIndex('updatedAt', 'updatedAt');
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function putThumbBlob(thumbKey, blob) {
  const db = await openThumbDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(THUMB_STORE, 'readwrite');
    tx.objectStore(THUMB_STORE).put({ thumbKey, blob, updatedAt: Date.now() });
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function deleteThumb(thumbKey) {
  if (!thumbKey) return;
  const db = await openThumbDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(THUMB_STORE, 'readwrite');
    tx.objectStore(THUMB_STORE).delete(thumbKey);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function deleteThumbMany(keys) {
  if (!Array.isArray(keys) || keys.length === 0) return;
  const db = await openThumbDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(THUMB_STORE, 'readwrite');
    const store = tx.objectStore(THUMB_STORE);
    keys.forEach((k) => { if (k) store.delete(k); });
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function clearAllThumbs() {
  const db = await openThumbDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(THUMB_STORE, 'readwrite');
    tx.objectStore(THUMB_STORE).clear();
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

function dataUrlToBlob(dataUrl) {
  const parts = dataUrl.split(',');
  const header = parts[0] || '';
  const mimeMatch = header.match(/data:(.*?);base64/i);
  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
  const b64 = parts[1] || '';
  const bin = atob(b64);
  const len = bin.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

async function saveThumbnailFromSource(thumbKey, source) {
  try {
    if (!thumbKey || !source) return;
    // 1) dataURL이면 바로 Blob으로 저장
    if (typeof source === 'string' && source.startsWith('data:image/')) {
      const blob = dataUrlToBlob(source);
      await putThumbBlob(thumbKey, blob);
      return;
    }
    // 2) http(s) URL이면 background에서 fetch (CORS 영향 거의 없음)
    if (typeof source === 'string' && (source.startsWith('http://') || source.startsWith('https://'))) {
      const res = await fetch(source, { cache: 'force-cache' });
      if (!res.ok) throw new Error('thumbnail fetch failed: ' + res.status);
      const blob = await res.blob();
      await putThumbBlob(thumbKey, blob);
      return;
    }
    // 3) Blob/ArrayBuffer 등도 가능(확장 대비)
    if (source instanceof Blob) {
      await putThumbBlob(thumbKey, source);
    }
  } catch (e) {
    console.warn('[ThumbDB] 썸네일 저장 실패(무시):', e);
  }
}

// ==================== 3-1. 화면 캡처 기반 썸네일 생성(가장 안정적) ====================
// content.js에서 비디오 영역의 boundingClientRect + devicePixelRatio를 보내면
// background에서 captureVisibleTab으로 현재 탭 화면을 캡처한 뒤 해당 영역만 잘라
// 썸네일로 저장합니다.

async function captureAndStoreCroppedThumb({ thumbKey, windowId, rect, dpr }) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.captureVisibleTab(
        windowId,
        { format: 'jpeg', quality: 70 },
        async (dataUrl) => {
          try {
            if (chrome.runtime.lastError) {
              throw new Error(chrome.runtime.lastError.message);
            }
            if (!dataUrl) throw new Error('captureVisibleTab returned empty');

            // dataURL -> Blob
            const res = await fetch(dataUrl);
            const fullBlob = await res.blob();

            // rect가 없으면 전체 저장
            if (!rect || !rect.width || !rect.height) {
              await putThumbBlob(thumbKey, fullBlob);
              return resolve(true);
            }

            const scale = Number(dpr) || 1;
            const sx = Math.max(0, Math.floor((rect.x || 0) * scale));
            const sy = Math.max(0, Math.floor((rect.y || 0) * scale));
            const sw = Math.max(1, Math.floor((rect.width || 1) * scale));
            const sh = Math.max(1, Math.floor((rect.height || 1) * scale));

            const bmp = await createImageBitmap(fullBlob);
            const canvas = new OffscreenCanvas(sw, sh);
            const ctx = canvas.getContext('2d');
            ctx.drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);

            const croppedBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.7 });
            await putThumbBlob(thumbKey, croppedBlob);
            resolve(true);
          } catch (e) {
            console.warn('[ThumbDB] captureVisibleTab 썸네일 생성 실패(무시):', e);
            resolve(false);
          }
        }
      );
    } catch (e) {
      console.warn('[ThumbDB] captureVisibleTab 호출 실패(무시):', e);
      resolve(false);
    }
  });
}

// ==================== 4. Firebase 인증 함수 ====================

async function signUp(email, password) {
  try {
    const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
    return { success: true, user: serializeUser(userCredential.user) };
  } catch (error) {
    console.error('[Firebase] 회원가입 실패:', error);
    return { success: false, error: error.code };
  }
}

async function signIn(email, password) {
  try {
    const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
    await syncFromCloud();
    return { success: true, user: serializeUser(userCredential.user) };
  } catch (error) {
    console.error('[Firebase] 로그인 실패:', error);
    return { success: false, error: error.code };
  }
}

async function signOut() {
  try {
    await firebase.auth().signOut();
    currentUser = null;
    return { success: true };
  } catch (error) {
    return { success: false, error: error.code };
  }
}

function getCurrentUser() {
  if (!authReady) return null;
  const user = firebase.auth().currentUser;
  return user ? serializeUser(user) : null;
}

function serializeUser(user) {
  if (!user) return null;
  return { uid: user.uid, email: user.email, displayName: user.displayName };
}

// ==================== 5. Firestore 데이터 관리 ====================

function normalizeHistoryForCloud(history) {
  // Firestore에는 thumbnail(dataURL/URL)을 절대 넣지 않음 (문서 1MB 방지)
  return (history || []).map((it) => {
    const copy = { ...it };
    delete copy.thumbnail;
    delete copy.thumbUrl;
    delete copy.thumbFallbackUrl;
    return copy;
  });
}

async function saveToCloud(watchHistory) {
  try {
    const user = firebase.auth().currentUser;
    if (!user) return { success: false, error: '로그인이 필요합니다.' };

    const cloudHistory = normalizeHistoryForCloud(watchHistory);

    await firebase.firestore().collection('users').doc(user.uid).set({
      email: user.email,
      watchHistory: cloudHistory,
      lastUpdated: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error('[Firebase] 저장 실패:', error);
    return { success: false, error: error.message };
  }
}

async function loadFromCloud() {
  try {
    const user = firebase.auth().currentUser;
    if (!user) return { success: false, error: '로그인이 필요합니다.' };

    const doc = await firebase.firestore().collection('users').doc(user.uid).get();
    return { success: true, data: doc.exists ? (doc.data().watchHistory || []) : [] };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function syncToCloud() {
  const result = await chrome.storage.local.get('watchHistory');
  if (result.watchHistory) await saveToCloud(result.watchHistory);
}

async function syncFromCloud() {
  const result = await loadFromCloud();
  if (result.success && result.data) {
    // 클라우드에는 썸네일이 없으므로(thumbKey만), 로컬 썸네일은 그대로 유지
    await chrome.storage.local.set({ watchHistory: result.data });
  }
}

// ==================== 6. 메시지 리스너 ====================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'signUp') { signUp(message.email, message.password).then(sendResponse); return true; }
  if (message.type === 'signIn') { signIn(message.email, message.password).then(sendResponse); return true; }
  if (message.type === 'signOut') { signOut().then(sendResponse); return true; }

  if (message.type === 'getCurrentUser') {
    if (!authReady) {
      console.log('[Background] Firebase 인증 초기화 중... (authReady: false)');
      sendResponse({ user: null, ready: false });
    } else {
      const user = getCurrentUser();
      console.log('[Background] getCurrentUser 응답:', user ? user.email : 'null');
      sendResponse({ user: user, ready: true });
    }
    return true;
  }

  if (message.type === 'getTabInfo') {
    if (sender.tab && sender.tab.id) {
      chrome.tabs.get(sender.tab.id, (tab) => {
        sendResponse({ url: tab.url || '', title: tab.title || '' });
      });
      return true;
    } else {
      sendResponse({ url: '', title: '' });
    }
    return true;
  }

  if (message.type === 'saveWatchHistory') {
    saveWatchHistory(message.data).then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === 'getWatchHistory') {
    getWatchHistory().then(history => sendResponse({ history }));
    return true;
  }

  if (message.type === 'deleteHistory') {
    deleteHistory(message.id).then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === 'clearAllHistory') {
    clearAllHistory().then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === 'syncToCloud') {
    syncToCloud().then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === 'syncFromCloud') {
    syncFromCloud().then(() => sendResponse({ success: true }));
    return true;
  }

  // content.js -> background: 썸네일 저장
  if (message.type === 'saveThumbnail') {
    saveThumbnailFromSource(message.thumbKey, message.source).then(() => sendResponse({ success: true }));
    return true;
  }

  // content.js -> background: 현재 화면을 캡처해서 비디오 영역만 잘라 썸네일 저장
  if (message.type === 'captureVisibleThumbnail') {
    const windowId = sender?.tab?.windowId;
    captureAndStoreCroppedThumb({
      thumbKey: message.thumbKey,
      windowId,
      rect: message.rect,
      dpr: message.dpr
    }).then((ok) => sendResponse({ success: !!ok }));
    return true;
  }
});

// ==================== 7. 시청 기록 관리 핵심 로직 ====================

const MAX_HISTORY = 100;

async function saveWatchHistory(data) {
  const history = await getWatchHistory();
  const existingIndex = history.findIndex(item => item.url === data.url);

  const historyItem = { ...data, id: data.url, lastWatched: Date.now() };

  if (existingIndex >= 0) history[existingIndex] = historyItem;
  else history.unshift(historyItem);

  // 최신순 정렬 + 100개 제한
  history.sort((a, b) => (b.lastWatched || 0) - (a.lastWatched || 0));
  const limitedHistory = history.slice(0, MAX_HISTORY);

  // 잘려나간 항목의 썸네일은 IndexedDB에서 삭제
  const removed = history.slice(MAX_HISTORY);
  const removedKeys = removed.map(x => x.thumbKey).filter(Boolean);
  if (removedKeys.length) await deleteThumbMany(removedKeys);

  await chrome.storage.local.set({ watchHistory: limitedHistory });

  // 로그인 상태면 자동으로 Firebase 동기화 (썸네일 제외)
  if (currentUser) {
    console.log('[Background] 시청기록 저장 완료 - Firebase 동기화 시작');
    await saveToCloud(limitedHistory);
    console.log('[Background] Firebase 동기화 완료');
  }
}

async function getWatchHistory() {
  const result = await chrome.storage.local.get('watchHistory');
  return (result.watchHistory || []).sort((a, b) => (b.lastWatched || 0) - (a.lastWatched || 0));
}

async function deleteHistory(id) {
  const history = await getWatchHistory();
  const target = history.find(item => item.id === id);
  const filtered = history.filter(item => item.id !== id);

  await chrome.storage.local.set({ watchHistory: filtered });

  // 썸네일 삭제
  if (target && target.thumbKey) await deleteThumb(target.thumbKey);

  if (currentUser) await saveToCloud(filtered);
}

async function clearAllHistory() {
  const history = await getWatchHistory();
  const keys = history.map(x => x.thumbKey).filter(Boolean);
  await chrome.storage.local.set({ watchHistory: [] });

  // 썸네일 전부 삭제
  if (keys.length) await deleteThumbMany(keys);

  if (currentUser) await saveToCloud([]);
}

console.log('[Background] Service Worker Ready');
