(function() {
    const WORKER_URL = 'https://gysadblock.rhdidtjr123.workers.dev/';
    
    function injectStyles(selectors) {
        if (!selectors || selectors.length === 0) return;
        let styleTag = document.getElementById('gys-block-style');
        if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = 'gys-block-style';
            (document.head || document.documentElement).appendChild(styleTag);
        }
        styleTag.innerHTML = `
            ${selectors.join(', ')} {
                display: none !important;
                height: 0 !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        `;
    }

    function runRemovalLogic(config) {
        config.adSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => el.remove());
        });

        if (window.location.hostname.includes('tvwiki')) {
            const iframe = document.getElementById('view_iframe');
            if (iframe) {
                const playerUrl = iframe.getAttribute(`data-player${config.preferredPlayer}`);
                if (playerUrl && iframe.src !== playerUrl) {
                    iframe.src = playerUrl;
                }
            }
        }
    }

    async function initialize() {
        chrome.storage.local.get(['adConfig'], (result) => {
            if (result.adConfig) {
                injectStyles(result.adConfig.adSelectors);
                runRemovalLogic(result.adConfig);
            }
        });

        try {
            const response = await fetch(WORKER_URL);
            const config = await response.json();
            
            injectStyles(config.adSelectors);
            chrome.storage.local.set({ adConfig: config });

            const observer = new MutationObserver(() => runRemovalLogic(config));
            observer.observe(document.documentElement, { childList: true, subtree: true });
            
            runRemovalLogic(config);
        } catch (e) {
            console.error("GYS Blocker Error:", e);
        }
    }

    initialize();
})();