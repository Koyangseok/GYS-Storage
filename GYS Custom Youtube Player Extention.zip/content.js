(() => {
  "use strict";

  // =========================
  // 설정
  // =========================
  const EXTERNAL_PLAYER_BASE = "https://youtube-test-gilt.vercel.app/youp.html";

  const PLAYER_PARAMS = {
    start: "0",
    end: "0",
    rel: "0",
  };

  const CUSTOM_WRAPPER_ID = "gys-custom-player-wrapper";
  const CUSTOM_IFRAME_ID = "gys-custom-player-iframe";
  const STYLE_ID = "gys-custom-player-style";
  const READY_CLASS = "gys-external-ready";

  let applying = false;
  let lastUrl = "";
  let lastExternalSrc = "";

  // =========================
  // 페이지 타입
  // =========================
  function isShortsPage() {
    return location.pathname.startsWith("/shorts/");
  }

  function isWatchPage() {
    try {
      const url = new URL(location.href);
      return url.pathname === "/watch" && !!url.searchParams.get("v");
    } catch {
      return false;
    }
  }

  function updatePageType() {
    if (isShortsPage()) {
      document.body.setAttribute("data-page-type", "shorts");
    } else {
      document.body.removeAttribute("data-page-type");
    }
  }

  // =========================
  // videoId 추출 (일반 watch만)
  // =========================
  function getVideoIdFromUrl() {
    try {
      const url = new URL(location.href);

      if (url.pathname === "/watch") {
        return url.searchParams.get("v");
      }
      return null;
    } catch {
      return null;
    }
  }

  function buildExternalSrc(videoId) {
    const qs = new URLSearchParams();
    qs.set("v", videoId);
    qs.set("start", PLAYER_PARAMS.start);
    qs.set("end", PLAYER_PARAMS.end);
    qs.set("rel", PLAYER_PARAMS.rel);
    return `${EXTERNAL_PLAYER_BASE}?${qs.toString()}`;
  }

  function wait(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // =========================
  // 전체 페이지 영상 무음 처리
  // =========================
  function muteAllVideosOnPage() {
    const vids = document.querySelectorAll("video");
    vids.forEach((v) => {
      try {
        v.muted = true;
        v.volume = 0;
      } catch {}
    });
  }

  // =========================
  // 외부(임베디드) 플레이어 완전 정지 (홈으로 가면 꺼짐)
  // =========================
  function disableExternalPlayerOnNonWatch() {
    document.body.classList.remove(READY_CLASS);

    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);

    if (wrapper) wrapper.style.display = "none";

    if (iframe) {
      if (iframe.src !== "about:blank") iframe.src = "about:blank";
    }

    lastExternalSrc = "";
  }

  function enableExternalPlayerUI() {
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "block";
  }

  // =========================
  // 미니플레이어 완전 차단
  // =========================
  function forceCloseMiniPlayer() {
    document.body.classList.remove("ytp-miniplayer-active");
    document.querySelectorAll("ytd-miniplayer").forEach((el) => el.remove());
  }

  document.addEventListener(
    "click",
    (e) => {
      const t = e.target;
      if (
        t?.closest(".ytp-miniplayer-button") ||
        t?.closest("[aria-label='미니플레이어']")
      ) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true
  );

  // =========================
  // 원본 영상 정지/무음 (watch 페이지에서만 강제 정지)
  // =========================
  function stopOriginalYouTubeVideoOnWatchOnly() {
    if (isShortsPage()) return;
    if (!isWatchPage()) return;

    const vids = document.querySelectorAll("video");
    vids.forEach((v) => {
      try {
        v.pause();
        v.muted = true;
        v.volume = 0;
      } catch {}
    });
  }

  // play 이벤트 감지:
  // - watch 페이지: 강제 pause + mute
  // - 메인창/기타 페이지: pause는 하지 않고 mute만
  function blockOriginalAutoplayByEvent() {
    document.addEventListener(
      "play",
      (e) => {
        if (isShortsPage()) return;

        const t = e.target;
        if (t && t.tagName === "VIDEO") {
          try {
            if (isWatchPage()) {
              t.pause();
              t.muted = true;
              t.volume = 0;
            } else {
              t.muted = true;
              t.volume = 0;
            }
          } catch {}
        }
      },
      true
    );
  }

  // =========================
  // ✅ 스타일 주입
  // - IMPORTANT: 외부 iframe이 준비된(READY_CLASS) 경우에만 원본 영상 숨김
  // =========================
  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      /* ===== 미니플레이어 제거 ===== */
      ytd-miniplayer,
      .ytp-miniplayer-ui,
      .ytp-miniplayer-scrim,
      .ytp-miniplayer-close-button,
      .ytp-miniplayer-expand-watch-page-button {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }

      /* ✅ 외부 플레이어가 준비된 경우에만 원본 숨김 (검은화면 방지 핵심) */
      body.${READY_CLASS}:not([data-page-type="shorts"]) #movie_player video.html5-main-video,
      body.${READY_CLASS}:not([data-page-type="shorts"]) #movie_player .html5-video-container {
        opacity: 0 !important;
        pointer-events: none !important;
      }

      body:not([data-page-type="shorts"]) #movie_player {
        position: relative !important;
      }

      #${CUSTOM_WRAPPER_ID} {
        position: absolute !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
        z-index: 9999999 !important;
        background: #000 !important;
        overflow: hidden !important;
        display: none;
      }

      #${CUSTOM_IFRAME_ID} {
        width: 100% !important;
        height: 100% !important;
        border: 0 !important;
      }
    `;
    document.documentElement.appendChild(style);
  }

  // =========================
  // 오버레이를 #movie_player 내부에 생성
  // =========================
  function ensureOverlayInsideMoviePlayer() {
    injectStyleOnce();

    const moviePlayer = document.querySelector("#movie_player");
    if (!moviePlayer) return false;

    let wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    let iframe = document.getElementById(CUSTOM_IFRAME_ID);

    if (!wrapper) {
      wrapper = document.createElement("div");
      wrapper.id = CUSTOM_WRAPPER_ID;
      moviePlayer.appendChild(wrapper);
    } else if (wrapper.parentElement !== moviePlayer) {
      moviePlayer.appendChild(wrapper);
    }

    if (!iframe) {
      iframe = document.createElement("iframe");
      iframe.id = CUSTOM_IFRAME_ID;
      iframe.allow = "autoplay; fullscreen; encrypted-media; picture-in-picture";
      iframe.allowFullscreen = true;
      wrapper.appendChild(iframe);
    }

    return true;
  }

  // =========================
  // iframe src 세팅
  // =========================
  function setIframeSrcIfChanged(newSrc) {
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (!iframe || !wrapper) return;

    if (newSrc === lastExternalSrc) return;

    lastExternalSrc = newSrc;
    iframe.src = newSrc;

    // ✅ src 세팅 성공 시: 외부 준비 완료 처리
    document.body.classList.add(READY_CLASS);
    wrapper.style.display = "block";

    console.log("[GYS] iframe src set:", newSrc);
  }

  // =========================
  // 적용
  // =========================
  async function applyReplacePlayer(force = false) {
    if (applying) return;

    updatePageType();
    forceCloseMiniPlayer();

    // 쇼츠는 원본 그대로
    if (isShortsPage()) return;

    const urlNow = location.href;
    if (!force && urlNow === lastUrl) return;

    applying = true;
    try {
      // watch가 아니면: 무음 + 외부 종료
      if (!isWatchPage()) {
        muteAllVideosOnPage();
        disableExternalPlayerOnNonWatch();
        lastUrl = urlNow;
        return;
      }

      // watch 페이지
      const videoId = getVideoIdFromUrl();
      if (!videoId) return;

      const ok = ensureOverlayInsideMoviePlayer();
      if (!ok) {
        // 새 탭 첫 로딩에서 movie_player가 아직 없을 수 있음 -> READY 끄고 원본 숨김 금지
        document.body.classList.remove(READY_CLASS);
        return;
      }

      enableExternalPlayerUI();
      stopOriginalYouTubeVideoOnWatchOnly();

      const externalSrc = buildExternalSrc(videoId);
      setIframeSrcIfChanged(externalSrc);

      lastUrl = urlNow;

      await wait(200);
      stopOriginalYouTubeVideoOnWatchOnly();
    } finally {
      applying = false;
    }
  }

  // =========================
  // 라우팅/변경 감지
  // =========================
  function hookYouTubeNavigateEvents() {
    window.addEventListener("yt-navigate-finish", () => {
      setTimeout(() => applyReplacePlayer(true), 80);
      setTimeout(() => applyReplacePlayer(true), 350);
      setTimeout(() => applyReplacePlayer(true), 900);
    });
  }

  function startUrlPolling() {
    let prev = location.href;
    setInterval(() => {
      const now = location.href;
      if (now !== prev) {
        prev = now;
        applyReplacePlayer(true);
      }
    }, 300);
  }

  function watchDomMutations() {
    const obs = new MutationObserver(() => {
      updatePageType();
      forceCloseMiniPlayer();

      if (!isShortsPage() && isWatchPage()) {
        // ✅ 새탭에서 가장 중요한 부분:
        // movie_player가 늦게 생기면 overlay만 만들고 끝나면 검은화면 가능 -> apply를 강제 재실행
        const ok = ensureOverlayInsideMoviePlayer();
        if (ok) applyReplacePlayer(true);
      } else {
        muteAllVideosOnPage();
        disableExternalPlayerOnNonWatch();
      }
    });

    obs.observe(document.documentElement, { childList: true, subtree: true });
  }

  // =========================
  // 시작 (새 탭 로딩 대응 리트라이 포함)
  // =========================
  function start() {
    updatePageType();
    injectStyleOnce();
    blockOriginalAutoplayByEvent();

    hookYouTubeNavigateEvents();
    watchDomMutations();
    startUrlPolling();

    // ✅ 새 탭 첫 로딩은 무조건 여러 번 시도 (타이밍 이슈 해결)
    applyReplacePlayer(true);
    setTimeout(() => applyReplacePlayer(true), 200);
    setTimeout(() => applyReplacePlayer(true), 600);
    setTimeout(() => applyReplacePlayer(true), 1200);

    // 안전 루프
    setInterval(() => {
      forceCloseMiniPlayer();

      if (isWatchPage()) {
        stopOriginalYouTubeVideoOnWatchOnly();
      } else {
        muteAllVideosOnPage();
        disableExternalPlayerOnNonWatch();
      }
    }, 600);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
