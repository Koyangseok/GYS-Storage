(() => {
  "use strict";

  // =========================
  // 설정
  // =========================
  const EXTERNAL_PLAYER_BASE = "https://youtube-test-gilt.vercel.app/youp.html";

  const PLAYER_PARAMS = {
    start: "0",
    end: "0",
    rel: "0",
  };

  const CUSTOM_WRAPPER_ID = "gys-custom-player-wrapper";
  const CUSTOM_IFRAME_ID = "gys-custom-player-iframe";
  const STYLE_ID = "gys-custom-player-style";

  let applying = false;
  let lastUrl = "";
  let lastExternalSrc = "";

  // =========================
  // 페이지 타입
  // =========================
  function isShortsPage() {
    return location.pathname.startsWith("/shorts/");
  }

  function isWatchPage() {
    try {
      const url = new URL(location.href);
      return url.pathname === "/watch" && !!url.searchParams.get("v");
    } catch {
      return false;
    }
  }

  function updatePageType() {
    if (isShortsPage()) {
      document.body.setAttribute("data-page-type", "shorts");
    } else {
      document.body.removeAttribute("data-page-type");
    }
  }

  // =========================
  // videoId 추출 (일반 watch만)
  // =========================
  function getVideoIdFromUrl() {
    try {
      const url = new URL(location.href);

      if (url.pathname === "/watch") {
        return url.searchParams.get("v");
      }

      // 쇼츠/메인/기타 페이지는 원본 플레이어 사용 (여기서는 교체 안함)
      return null;
    } catch {
      return null;
    }
  }

  function buildExternalSrc(videoId) {
    const qs = new URLSearchParams();
    qs.set("v", videoId);
    qs.set("start", PLAYER_PARAMS.start);
    qs.set("end", PLAYER_PARAMS.end);
    qs.set("rel", PLAYER_PARAMS.rel);
    return `${EXTERNAL_PLAYER_BASE}?${qs.toString()}`;
  }

  function wait(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // =========================
  // ✅ 메인창(홈) 포함 "전체 페이지 영상 무음" 처리
  // =========================
  function muteAllVideosOnPage() {
    const vids = document.querySelectorAll("video");
    vids.forEach((v) => {
      try {
        v.muted = true;
        v.volume = 0;
      } catch {}
    });
  }

  // =========================
  // ✅ 외부(임베디드) 플레이어 완전 정지 (홈으로 가면 꺼짐)
  // =========================
  function disableExternalPlayerOnNonWatch() {
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);

    if (wrapper) {
      wrapper.style.display = "none";
    }

    if (iframe) {
      // about:blank 로 바꿔서 "소리/재생" 완전 제거
      if (iframe.src !== "about:blank") iframe.src = "about:blank";
    }

    lastExternalSrc = "";
  }

  function enableExternalPlayerUI() {
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "block";
  }

  // =========================
  // 미니플레이어 완전 차단
  // =========================
  function forceCloseMiniPlayer() {
    document.body.classList.remove("ytp-miniplayer-active");
    document.querySelectorAll("ytd-miniplayer").forEach((el) => el.remove());
  }

  document.addEventListener(
    "click",
    (e) => {
      const t = e.target;
      if (
        t?.closest(".ytp-miniplayer-button") ||
        t?.closest("[aria-label='미니플레이어']")
      ) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true
  );

  // =========================
  // ✅ 원본 영상 정지/무음 (watch 페이지에서만 강제 정지)
  // =========================
  function stopOriginalYouTubeVideoOnWatchOnly() {
    if (isShortsPage()) return;
    if (!isWatchPage()) return;

    const vids = document.querySelectorAll("video");
    vids.forEach((v) => {
      try {
        v.pause();
        v.muted = true;
        v.volume = 0;
      } catch {}
    });
  }

  // ✅ play 이벤트 감지:
  // - watch 페이지: 강제 pause + mute
  // - 메인창/기타 페이지: pause는 하지 않고 mute만
  function blockOriginalAutoplayByEvent() {
    document.addEventListener(
      "play",
      (e) => {
        if (isShortsPage()) return;

        const t = e.target;
        if (t && t.tagName === "VIDEO") {
          try {
            if (isWatchPage()) {
              t.pause();
              t.muted = true;
              t.volume = 0;
            } else {
              // 홈/메인에서는 재생은 놔두고 "소리만 OFF"
              t.muted = true;
              t.volume = 0;
            }
          } catch {}
        }
      },
      true
    );
  }

  // =========================
  // 스타일 주입
  // =========================
  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      /* ===== 미니플레이어 제거 ===== */
      ytd-miniplayer,
      .ytp-miniplayer-ui,
      .ytp-miniplayer-scrim,
      .ytp-miniplayer-close-button,
      .ytp-miniplayer-expand-watch-page-button {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }

      /* ===== 일반 영상(watch)만 원본 숨김 ===== */
      body:not([data-page-type="shorts"]) #movie_player video.html5-main-video,
      body:not([data-page-type="shorts"]) #movie_player .html5-video-container {
        opacity: 0 !important;
        pointer-events: none !important;
      }

      body:not([data-page-type="shorts"]) #movie_player {
        position: relative !important;
      }

      #${CUSTOM_WRAPPER_ID} {
        position: absolute !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
        z-index: 9999999 !important;
        background: #000 !important;
        overflow: hidden !important;
      }

      #${CUSTOM_IFRAME_ID} {
        width: 100% !important;
        height: 100% !important;
        border: 0 !important;
      }
    `;
    document.documentElement.appendChild(style);
  }

  // =========================
  // 오버레이를 #movie_player 내부에 생성
  // =========================
  function ensureOverlayInsideMoviePlayer() {
    injectStyleOnce();

    const moviePlayer = document.querySelector("#movie_player");
    if (!moviePlayer) return false;

    let wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    let iframe = document.getElementById(CUSTOM_IFRAME_ID);

    if (!wrapper) {
      wrapper = document.createElement("div");
      wrapper.id = CUSTOM_WRAPPER_ID;
      moviePlayer.appendChild(wrapper);
    } else {
      if (wrapper.parentElement !== moviePlayer) {
        moviePlayer.appendChild(wrapper);
      }
    }

    if (!iframe) {
      iframe = document.createElement("iframe");
      iframe.id = CUSTOM_IFRAME_ID;
      iframe.allow =
        "autoplay; fullscreen; encrypted-media; picture-in-picture";
      iframe.allowFullscreen = true;
      wrapper.appendChild(iframe);
    }

    return true;
  }

  // =========================
  // iframe src 세팅 (같으면 절대 안 바꿈!)
  // =========================
  function setIframeSrcIfChanged(newSrc) {
    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (!iframe) return;

    if (newSrc === lastExternalSrc) return;

    lastExternalSrc = newSrc;
    iframe.src = newSrc;
    console.log("[GYS] iframe src set:", newSrc);
  }

  // =========================
  // 적용
  // =========================
  async function applyReplacePlayer(force = false) {
    if (applying) return;

    updatePageType();
    forceCloseMiniPlayer();

    // 쇼츠는 원본 그대로
    if (isShortsPage()) return;

    const urlNow = location.href;
    if (!force && urlNow === lastUrl) return;

    applying = true;
    try {
      // ✅ 메인창(홈) 등 watch가 아니면:
      // - 소리 무조건 끄기
      // - 외부 임베디드 iframe 플레이어는 완전 종료
      if (!isWatchPage()) {
        muteAllVideosOnPage();
        disableExternalPlayerOnNonWatch();
        lastUrl = urlNow;
        return;
      }

      // ✅ watch 페이지면 기존 방식대로 교체 적용
      const videoId = getVideoIdFromUrl();
      if (!videoId) return;

      stopOriginalYouTubeVideoOnWatchOnly();

      const ok = ensureOverlayInsideMoviePlayer();
      if (!ok) return;

      enableExternalPlayerUI();

      const externalSrc = buildExternalSrc(videoId);
      setIframeSrcIfChanged(externalSrc);

      lastUrl = urlNow;

      await wait(200);
      stopOriginalYouTubeVideoOnWatchOnly();
    } finally {
      applying = false;
    }
  }

  // =========================
  // 라우팅/변경 감지
  // =========================
  function hookYouTubeNavigateEvents() {
    window.addEventListener("yt-navigate-finish", () => {
      setTimeout(() => applyReplacePlayer(true), 80);
      setTimeout(() => applyReplacePlayer(true), 350);
    });
  }

  function startUrlPolling() {
    let prev = location.href;
    setInterval(() => {
      const now = location.href;
      if (now !== prev) {
        prev = now;
        applyReplacePlayer(true);
      }
    }, 300);
  }

  function watchDomMutations() {
    const obs = new MutationObserver(() => {
      updatePageType();
      forceCloseMiniPlayer();

      // ✅ watch 페이지에서는 오버레이 복구
      if (!isShortsPage() && isWatchPage()) {
        const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
        const iframe = document.getElementById(CUSTOM_IFRAME_ID);
        if (!wrapper || !iframe) {
          ensureOverlayInsideMoviePlayer();
        }
      } else {
        // ✅ 메인창에서는 무조건 무음 + iframe 종료
        muteAllVideosOnPage();
        disableExternalPlayerOnNonWatch();
      }
    });

    obs.observe(document.documentElement, { childList: true, subtree: true });
  }

  // =========================
  // 시작
  // =========================
  function start() {
    updatePageType();
    injectStyleOnce();
    blockOriginalAutoplayByEvent();

    hookYouTubeNavigateEvents();
    watchDomMutations();
    startUrlPolling();

    ensureOverlayInsideMoviePlayer();
    applyReplacePlayer(true);

    // 안전 루프
    setInterval(() => {
      forceCloseMiniPlayer();

      if (isWatchPage()) {
        stopOriginalYouTubeVideoOnWatchOnly();
      } else {
        muteAllVideosOnPage();
        disableExternalPlayerOnNonWatch();
      }
    }, 600);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
