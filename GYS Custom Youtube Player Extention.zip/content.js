(() => {
  "use strict";

  // =========================
  // 설정
  // =========================
  const EXTERNAL_PLAYER_BASE = "https://youtube-test-gilt.vercel.app/youp.html";

  const PLAYER_PARAMS = { start: "0", end: "0", rel: "0" };

  const CUSTOM_WRAPPER_ID = "gys-custom-player-wrapper";
  const CUSTOM_IFRAME_ID = "gys-custom-player-iframe";
  const STYLE_ID = "gys-custom-player-style";
  const READY_CLASS = "gys-custom-player-ready";

  // ✅ watch 페이지에서 원본 영상은 무조건 무음 유지(Shorts 제외)
  const ALWAYS_MUTE_ORIGINAL = true;

  // ✅ watch 페이지 원본 영상 0.3초 재생 후 정지 (외부 iframe 쓰는 경우만)
  const ORIGINAL_PLAY_MS = 300;

  // ✅ 폴백(임베드 제한 -> 원본 복귀) 시 소리 허용 여부
  const FALLBACK_ALLOW_SOUND = true;

  // ✅ 미니플레이어 차단
  const KILL_MINIPLAYER = true;

  // =========================
  // 상태
  // =========================
  let applying = false;
  let lastUrl = "";
  let lastExternalSrc = "";
  let pageType = "";

  // 폴백(원본 복귀) 플래그
  let FORCE_ORIGINAL = false;
  let FORCE_VIDEO_ID = "";

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  // =========================
  // 페이지 타입
  // =========================
  function isShortsPage() {
    return location.pathname.startsWith("/shorts");
  }
  function isWatchPage() {
    return location.pathname === "/watch";
  }
  function isHomeGridLikePage() {
    const p = location.pathname;
    return p === "/" || p.startsWith("/feed") || p.startsWith("/results");
  }
  function updatePageType() {
    if (isShortsPage()) pageType = "shorts";
    else if (isWatchPage()) pageType = "watch";
    else if (isHomeGridLikePage()) pageType = "grid";
    else pageType = "other";
  }

  // =========================
  // video id
  // =========================
  function getVideoIdFromUrl() {
    try {
      const u = new URL(location.href);
      return u.searchParams.get("v") || "";
    } catch {
      return "";
    }
  }

  // =========================
  // 외부 플레이어 URL
  // =========================
  function buildExternalSrc(videoId) {
    const u = new URL(EXTERNAL_PLAYER_BASE);
    u.searchParams.set("v", videoId);
    u.searchParams.set("start", String(PLAYER_PARAMS.start ?? "0"));
    u.searchParams.set("end", String(PLAYER_PARAMS.end ?? "0"));
    u.searchParams.set("rel", String(PLAYER_PARAMS.rel ?? "0"));
    return u.toString();
  }

  function getExternalOrigin() {
    try {
      return new URL(EXTERNAL_PLAYER_BASE).origin;
    } catch {
      return "";
    }
  }

  // =========================
  // ✅ 미니플레이어 완전 제거
  // =========================
  function killMiniPlayer() {
    if (!KILL_MINIPLAYER) return;
    try {
      document.querySelectorAll("ytd-miniplayer").forEach((el) => el.remove());
      document.querySelectorAll(".ytp-miniplayer-ui").forEach((el) => el.remove());

      const closeBtn = document.querySelector(".ytp-miniplayer-close-button");
      if (closeBtn) closeBtn.click();

      const flexy = document.querySelector("ytd-watch-flexy");
      if (flexy) {
        flexy.removeAttribute("miniplayer");
        flexy.classList.remove("miniplayer");
      }
    } catch {}
  }

  // =========================
  // 광고/빈칸 제거
  // =========================
  const AD_SELECTORS = [
    "ytd-rich-item-renderer ytd-display-ad-renderer",
    "ytd-rich-item-renderer ytd-ad-slot-renderer",
    "ytd-rich-item-renderer ytd-in-feed-ad-layout-renderer",
    "ytd-rich-section-renderer",
    "ytd-statement-banner-renderer",
    "ytd-banner-promo-renderer",
    "ytd-action-companion-ad-renderer",
    "ytd-companion-slot-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-promoted-video-renderer",
    "ytd-ads-engagement-panel-content-renderer",
    "ytd-ad-hover-text-button-renderer",
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-in-feed-ad-layout-renderer[modern]",
    "ytd-video-masthead-ad-advertiser-info-renderer",
    "ytd-video-masthead-ad-primary-video-renderer",
    "ytd-shopping-title",
    "ytd-reel-shelf-renderer[is-ad]",
    "ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-ads']",
    "tp-yt-paper-dialog ytd-enforcement-message-view-model",
  ];

  function removeYouTubeAds(root = document) {
    try {
      const sel = AD_SELECTORS.join(",");
      const isGrid = isHomeGridLikePage();
      root.querySelectorAll(sel).forEach((adEl) => {
        if (isGrid) {
          const container = adEl.closest("ytd-rich-item-renderer, ytd-rich-section-renderer");
          (container || adEl).remove();
        } else {
          adEl.remove();
        }
      });
    } catch {}
  }

  function cleanupGridHoles() {
    try {
      document
        .querySelectorAll(
          "ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-in-feed-ad-layout-renderer"
        )
        .forEach((el) => {
          const isEmpty =
            !el.innerText ||
            el.innerText.trim() === "" ||
            el.querySelector("ytd-display-ad-renderer, ytd-ad-slot-renderer");
          if (isEmpty) el.remove();
        });
    } catch {}
  }

  function forceGridReflow() {
    try {
      const grid = document.querySelector("ytd-rich-grid-renderer");
      if (!grid) return;
      grid.style.transform = "translateZ(0)";
      grid.offsetHeight;
      grid.style.transform = "";
    } catch {}
  }

  // =========================
  // UI 삽입 (외부 iframe 오버레이)
  // =========================
  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;

    const st = document.createElement("style");
    st.id = STYLE_ID;
    st.textContent = `
      #${CUSTOM_WRAPPER_ID}{
        position:absolute;
        inset:0;
        z-index:999999;
        display:none;
        background:#000;
      }
      #${CUSTOM_WRAPPER_ID} iframe{
        width:100%;
        height:100%;
        border:0;
        display:block;
      }
      body.${READY_CLASS} #${CUSTOM_WRAPPER_ID}{
        display:block;
      }

      /* ✅ 미니플레이어 UI 완전 숨김 */
      ytd-miniplayer,
      .ytp-miniplayer-ui {
        display:none !important;
        visibility:hidden !important;
        pointer-events:none !important;
        opacity:0 !important;
      }
    `;
    document.documentElement.appendChild(st);
  }

  function ensureOverlayInsideMoviePlayer() {
    const movie = document.getElementById("movie_player");
    if (!movie) return false;

    let wrap = document.getElementById(CUSTOM_WRAPPER_ID);
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.id = CUSTOM_WRAPPER_ID;

      const iframe = document.createElement("iframe");
      iframe.id = CUSTOM_IFRAME_ID;
      iframe.allow = "autoplay; encrypted-media; fullscreen; picture-in-picture";
      iframe.allowFullscreen = true;

      wrap.appendChild(iframe);
      movie.style.position = "relative";
      movie.appendChild(wrap);
    }
    return true;
  }

  function setIframeSrcIfChanged(src) {
    if (!src || src === lastExternalSrc) return;
    lastExternalSrc = src;

    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (!iframe) return;

    iframe.src = src;
  }

  // ✅ watch 밖에서는 외부 iframe을 "완전 종료" (소리 계속 나는 원인 1순위 해결)
  function disableExternalPlayerOnNonWatch() {
    document.body.classList.remove(READY_CLASS);

    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "none";

    const iframe = document.getElementById(CUSTOM_IFRAME_ID);
    if (iframe) {
      try {
        iframe.src = "about:blank"; // ✅ 언로드해서 소리 즉시 끊기
      } catch {}
    }

    lastExternalSrc = ""; // ✅ 다음 watch 진입 시 다시 정상 로드
  }

  function enableExternalPlayerUI() {
    document.body.classList.add(READY_CLASS);
    const wrapper = document.getElementById(CUSTOM_WRAPPER_ID);
    if (wrapper) wrapper.style.display = "block";
  }

  // =========================
  // ✅ “진짜 강제 무음” (muted + volume=0)
  // =========================
  const guardedMedia = new WeakSet();

  function hardMuteMedia(el) {
    if (!el) return;
    try {
      el.muted = true;
      el.defaultMuted = true;
      el.volume = 0;
      el.setAttribute("muted", "");
    } catch {}
  }

  function shouldMuteOriginalNow() {
    if (!ALWAYS_MUTE_ORIGINAL) return false;
    if (isShortsPage()) return false;

    // ✅ 폴백 상태 + 소리 허용이면 mute 금지
    if (
      FALLBACK_ALLOW_SOUND &&
      FORCE_ORIGINAL &&
      isWatchPage() &&
      getVideoIdFromUrl() === FORCE_VIDEO_ID
    ) {
      return false;
    }
    return true;
  }

  function guardMediaElement(el) {
    if (!el || guardedMedia.has(el)) return;
    guardedMedia.add(el);

    if (shouldMuteOriginalNow()) hardMuteMedia(el);

    el.addEventListener(
      "volumechange",
      () => {
        if (!shouldMuteOriginalNow()) return;
        hardMuteMedia(el);
      },
      true
    );
  }

  function hardMuteAllMediaOnPage() {
    if (!shouldMuteOriginalNow()) return;

    document.querySelectorAll("video, audio").forEach((m) => {
      guardMediaElement(m);
      hardMuteMedia(m);
    });

    try {
      const mp = document.getElementById("movie_player");
      if (mp?.mute) mp.mute();
      if (mp?.setVolume) mp.setVolume(0);
    } catch {}
  }

  // =========================
  // ✅ watch 페이지에서 원본 0.3초 정지용
  // =========================
  const pauseTimerMap = new WeakMap();

  function playBrieflyMutedThenPause(videoEl) {
    if (!videoEl) return;
    if (pauseTimerMap.has(videoEl)) return;

    if (shouldMuteOriginalNow()) hardMuteMedia(videoEl);

    const tid = setTimeout(() => {
      try {
        videoEl.pause();
      } catch {}
      pauseTimerMap.delete(videoEl);
    }, ORIGINAL_PLAY_MS);

    pauseTimerMap.set(videoEl, tid);
  }

  function cancelPauseTimer(videoEl) {
    const tid = pauseTimerMap.get(videoEl);
    if (tid) {
      clearTimeout(tid);
      pauseTimerMap.delete(videoEl);
    }
  }

  // =========================
  // ✅ 미니플레이어 버튼/단축키 방지
  // =========================
  document.addEventListener(
    "click",
    (e) => {
      const t = e.target;
      if (
        t?.closest(".ytp-miniplayer-button") ||
        t?.closest("[aria-label='미니플레이어']") ||
        t?.closest("[title*='미니플레이어']")
      ) {
        e.preventDefault();
        e.stopPropagation();
        killMiniPlayer();
      }
    },
    true
  );

  document.addEventListener(
    "keydown",
    (e) => {
      try {
        if (!KILL_MINIPLAYER) return;
        if (e.key?.toLowerCase() === "i") {
          const tag = (document.activeElement && document.activeElement.tagName) || "";
          if (tag === "INPUT" || tag === "TEXTAREA") return;
          e.preventDefault();
          e.stopPropagation();
          killMiniPlayer();
        }
      } catch {}
    },
    true
  );

  // =========================
  // ✅ watch 페이지 원본 영상 제어
  // =========================
  function stopOriginalYouTubeVideoOnWatchOnly() {
    // ✅ 폴백(원본 복귀) 상태면 원본은 방해하지 않음
    if (
      FORCE_ORIGINAL &&
      isWatchPage() &&
      getVideoIdFromUrl() === FORCE_VIDEO_ID
    ) {
      // 폴백이지만 소리 허용이 꺼져있으면 무음만 유지
      if (!FALLBACK_ALLOW_SOUND) hardMuteAllMediaOnPage();
      return;
    }

    if (isShortsPage()) return;
    if (!isWatchPage()) return;

    document.querySelectorAll("video").forEach((v) => {
      try {
        guardMediaElement(v);
        hardMuteMedia(v);
        if (!v.paused) playBrieflyMutedThenPause(v);
      } catch {}
    });
  }

  // =========================
  // ✅ (중요 수정) play 이벤트 차단: 폴백이면 절대 멈추지 않게
  // =========================
  function blockOriginalAutoplayByEvent() {
    document.addEventListener(
      "play",
      (e) => {
        if (isShortsPage()) return;

        // ✅ fallback(원본 복귀) 상태면 원본 재생을 방해하지 않음
        if (
          FORCE_ORIGINAL &&
          isWatchPage() &&
          getVideoIdFromUrl() === FORCE_VIDEO_ID
        ) {
          return;
        }

        const t = e.target;
        if (t && (t.tagName === "VIDEO" || t.tagName === "AUDIO")) {
          try {
            guardMediaElement(t);

            if (isWatchPage()) {
              // 외부 iframe 쓰는 경우 원본은 무음 + 0.3초 후 정지
              if (shouldMuteOriginalNow()) hardMuteMedia(t);
              playBrieflyMutedThenPause(t);
            } else {
              // watch 제외 페이지는 원본 무음만
              if (shouldMuteOriginalNow()) hardMuteMedia(t);
            }
          } catch {}
        }
      },
      true
    );
  }

  // =========================
  // ✅ 폴백: 원본 복귀 재생(소리 정책 반영)
  // =========================
  function resumeOriginalPlayerPlayback() {
    try {
      const v = document.querySelector("#movie_player video.html5-main-video");
      if (!v) return;

      // ✅ 폴백 재생 방해 타이머 제거
      cancelPauseTimer(v);

      if (!FALLBACK_ALLOW_SOUND) {
        hardMuteMedia(v);
      } else {
        try {
          v.muted = false;
          v.defaultMuted = false;
          v.removeAttribute("muted");
          if (!v.volume || v.volume === 0) v.volume = 1;
        } catch {}

        try {
          const mp = document.getElementById("movie_player");
          if (mp?.unMute) mp.unMute();
          if (mp?.setVolume) mp.setVolume(100);
        } catch {}
      }

      const p = v.play?.();
      if (p && typeof p.catch === "function") p.catch(() => {});

      // ✅ 한 번 더 안전하게 타이머 제거
      cancelPauseTimer(v);
    } catch {}
  }

  function fallbackToOriginalPlayer(videoId) {
    FORCE_ORIGINAL = true;
    FORCE_VIDEO_ID = videoId || "";

    // 외부 iframe은 폴백에서는 사용 안 함(소리 누수 방지)
    disableExternalPlayerOnNonWatch();

    // 원본 재생 복귀(폴백 재생은 멈추지 않음)
    resumeOriginalPlayerPlayback();

    // 폴백에서 무음 유지 옵션이면 적용
    hardMuteAllMediaOnPage();

    killMiniPlayer();
  }

  function hookEmbedErrorMessage() {
    const externalOrigin = getExternalOrigin();

    window.addEventListener("message", (ev) => {
      const d = ev?.data;
      if (!d || d.type !== "GYS_EMBED_ERROR") return;
      if (externalOrigin && ev.origin !== externalOrigin) return;

      const cur = getVideoIdFromUrl();
      if (!cur || cur !== d.videoId) return;

      fallbackToOriginalPlayer(d.videoId);
    });
  }

  // =========================
  // ✅ URL 변경 감지 (SPA)
  // =========================
  function hookYouTubeNavigateEvents() {
    window.addEventListener("yt-navigate-finish", () => {
      killMiniPlayer();
      updatePageType();
      removeYouTubeAds();
      cleanupGridHoles();
      forceGridReflow();
      applyReplacePlayer(false);
    });

    window.addEventListener("popstate", () => {
      killMiniPlayer();
      updatePageType();
      removeYouTubeAds();
      cleanupGridHoles();
      forceGridReflow();
      applyReplacePlayer(false);
    });
  }

  // =========================
  // ✅ DOM 변화 감지
  // =========================
  function watchDomMutations() {
    const obs = new MutationObserver(() => {
      killMiniPlayer();

      try {
        removeYouTubeAds();
        cleanupGridHoles();
        forceGridReflow();
      } catch {}

      applyReplacePlayer(false);
    });

    obs.observe(document.documentElement, { childList: true, subtree: true });
  }

  // =========================
  // ✅ URL 폴링
  // =========================
  function startUrlPolling() {
    setInterval(() => {
      const urlNow = location.href;
      if (urlNow !== lastUrl) {
        killMiniPlayer();
        updatePageType();
        removeYouTubeAds();
        cleanupGridHoles();
        forceGridReflow();
        applyReplacePlayer(false);
      }
    }, 700);
  }

  // =========================
  // ✅ watch일 때만 외부 iframe으로 대체
  // =========================
  async function applyReplacePlayer(force) {
    if (applying) return;
    applying = true;

    try {
      const urlNow = location.href;
      if (!force && urlNow === lastUrl) return;

      killMiniPlayer();
      removeYouTubeAds();
      cleanupGridHoles();
      forceGridReflow();

      // 어디 페이지든 원본은 무음 유지(Shorts 제외)
      hardMuteAllMediaOnPage();

      // shorts는 외부 iframe 사용 안함
      if (isShortsPage()) {
        disableExternalPlayerOnNonWatch();
        lastUrl = urlNow;
        return;
      }

      // ✅ watch가 아니면: 외부 iframe 완전 종료 + 원본도 정지/무음
      if (!isWatchPage()) {
        disableExternalPlayerOnNonWatch();

        try {
          const mp = document.getElementById("movie_player");
          if (mp?.pauseVideo) mp.pauseVideo();
          if (mp?.mute) mp.mute();
          if (mp?.setVolume) mp.setVolume(0);
        } catch {}

        try {
          document.querySelectorAll("video, audio").forEach((v) => {
            try { v.pause(); } catch {}
            try { v.muted = true; v.volume = 0; } catch {}
          });
        } catch {}

        killMiniPlayer();
        lastUrl = urlNow;
        return;
      }

      const videoId = getVideoIdFromUrl();
      if (!videoId) return;

      // 다른 영상으로 이동하면 폴백 해제
      if (FORCE_ORIGINAL && FORCE_VIDEO_ID && videoId !== FORCE_VIDEO_ID) {
        FORCE_ORIGINAL = false;
        FORCE_VIDEO_ID = "";
      }

      const ok = ensureOverlayInsideMoviePlayer();
      if (!ok) {
        document.body.classList.remove(READY_CLASS);
        return;
      }

      // ✅ 폴백 유지 중이면 외부 플레이어 사용 안 함 + 원본 정상 재생
      if (FORCE_ORIGINAL && videoId === FORCE_VIDEO_ID) {
        disableExternalPlayerOnNonWatch();
        resumeOriginalPlayerPlayback();
        lastUrl = urlNow;
        killMiniPlayer();
        return;
      }

      // ✅ 외부 iframe 활성화
      enableExternalPlayerUI();
      stopOriginalYouTubeVideoOnWatchOnly();

      const externalSrc = buildExternalSrc(videoId);
      setIframeSrcIfChanged(externalSrc);

      lastUrl = urlNow;

      await wait(200);
      stopOriginalYouTubeVideoOnWatchOnly();
      await wait(400);
      stopOriginalYouTubeVideoOnWatchOnly();
      killMiniPlayer();
    } finally {
      applying = false;
    }
  }

  // =========================
  // 시작
  // =========================
  function start() {
    updatePageType();
    injectStyleOnce();

    blockOriginalAutoplayByEvent(); // ✅ 폴백이면 재생 방해 안 함
    hookEmbedErrorMessage();

    removeYouTubeAds();
    cleanupGridHoles();
    forceGridReflow();
    killMiniPlayer();

    hookYouTubeNavigateEvents();
    watchDomMutations();
    startUrlPolling();

    // ✅ 원본 무음 강제 유지 (Shorts 제외)
    setInterval(() => {
      hardMuteAllMediaOnPage();
    }, 250);

    // ✅ 미니플레이어 계속 제거
    setInterval(() => {
      killMiniPlayer();
    }, 300);

    applyReplacePlayer(true);
    setTimeout(() => applyReplacePlayer(true), 200);
    setTimeout(() => applyReplacePlayer(true), 600);
    setTimeout(() => applyReplacePlayer(true), 1200);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
